--require "bootstrap_d"
-- require "bootstrap_app"

--local ptm = require "presstest.PressTestManager"
--ptm.ptm_main(1)

--require "utils.test_attrib"
require "behaviac.test_behaviac"
