local tbl = {}

local a = { values=  { foo = 1 } }

local iter = function(value)
    local function loop(t,k)
        return next(t,k)
    end
    return loop, value
end

local mt = {
    __pairs = function(self)
        local values = rawget(self, "values")
        return iter(values)
    end
}

setmetatable(a,mt)

tbl.a = a

local function trav(k,t)
    if type(t) == "table" then
        print(k, t)
        for k,v in pairs(t) do
            trav(k,v)
        end
    end
end

trav("",tbl)