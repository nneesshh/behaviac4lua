local a = { values=  { foo = 1 } }

local iter = function(value)
    local function loop(t,k)
        return next(t,k)
    end
    return loop, value
end

local mt = {
    __pairs = function(self)
        print("xxxx")
        local values = rawget(self, "values")
        return iter(values)
    end
}

setmetatable(a,mt)

for k,v in pairs(a) do
    print(k, v)
end   