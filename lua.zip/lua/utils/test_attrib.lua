local attrib = require "attrib"

local e = attrib.expression {
	"攻击 = 力量 * 10",
    "HP = (耐力 +10) *2",
    "FOO = 攻击 + HP",
}

local a = attrib.new(e)

a["力量"] = 3
a["耐力"] = 4

print("a===========================")
print("1111111111111111111111111")
for k,v in pairs(a) do
	print(k,v)
end

a("力量",1)

print("a===========================")
print("2222222222222222222222222")
for k,v in pairs(a) do
	print(k,v)
end
