--
require "bootstrap"

local int64 = require "int64"
local pb = require "pb"
local json = require "rapidjson"

--
package.path = package.path .. ";./lua/FightModel/?.lua"
package.path = package.path .. ";./lua/protobuf/?.lua;./lua/proto_pb/?.lua"

ModuleRequire = ModuleRequire or require

require "table.zh_cn"
require "table.config_all"
require "table.config_fight"

-- _ModType is used by protobuf gen lua (which is modified by obsidian team)
_ModType = {}
--[[]]
require "Gate_pb"
require "Game_pb"
require "UserItem_pb"
require "UserOrder_pb"
require "UserFacility_pb"
require "UserShip_pb"
require "UserSailor_pb"
require "UserNavigation_pb"
require "UserBean_pb"
require "UserExplore_pb"
require "UserHarbour_pb"
require "NPC_pb"
require "Task_pb"
require "Manual_pb"
require "Development_pb"
require "Chat_pb"
require "UserMap_pb"
require "Chest_pb"
require "Development_pb"
--[[]]]]

ATTRIBUTE = {
  POWER            = 1, 
  AGILE            = 2, 
  INTELLIGENCE     = 3, 
  CORPOREITY       = 4, 
  LIFE             = 11, 
  PHYSICAL_ATTACK  = 12, 
  PHYSICAL_DEFENSE = 14, 
  MAGIC_ATTACK     = 13, 
  MAGIC_DEFENSE    = 15
}