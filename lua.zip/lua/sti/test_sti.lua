local sti = require "sti"

-- Grab window size
windowWidth  = 1024
windowHeight = 768

-- Load a map exported to Lua from Tiled
map = sti("assets/maps/map01.lua", { })

-- Create a Custom Layer
map:addCustomLayer("Sprite Layer", 3)
