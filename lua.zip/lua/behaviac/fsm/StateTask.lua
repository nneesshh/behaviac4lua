--- Behaviac lib Component: state task.
-- @module StateTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(pdir .. "enums")
local common = require(pdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local LeafTask = require(pdir .. "core.LeafTask")
local StateTask = class("StateTask", LeafTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("StateTask", StateTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("StateTask", "LeafTask")
local _M = StateTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_nextStateId = 0
end

function _M:release()
    _M.super.release(self)
end

function _M:copyto(target)
    _M.super.copyto(self, target)
end

function _M:getNextStateId()
    return m_nextStateId
end

function _M:IsEndState()
    _G.BEHAVIAC_ASSERT(self:getNode() and self:getNode():isState(), "node is not a state")

    local pStateNode = self:getNode()
    return pStateNode:isEndState()
end

function _M:onEnter(agent)
    --_G.BEHAVIAC_UNUSED_VAR(agent)
    self.m_nextStateId = -1
    return true
end

function _M:onExit(agent, s)
    --_G.BEHAVIAC_UNUSED_VAR(agent)
    --_G.BEHAVIAC_UNUSED_VAR(s)
end

function _M:update(agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(childStatus == BT_RUNNING)
    --_G.BEHAVIAC_UNUSED_VAR(childStatus)
    _G.BEHAVIAC_ASSERT(self:getNode() and self:getNode():isState(), "node is not a state")

    local pStateNode = self:getNode()
    return pStateNode:update(agent, tick, self.m_nextStateId)
end

return _M