--- Behaviac lib Component: state fms node.
-- @module State.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(pdir .. "enums")
local common = require(pdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local BaseNode = require(pdir .. "core.BaseNode")
local State = class("State", BaseNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("State", State)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("State", "BaseNode")
local _M = State

local StateTask = require(cwd .. "StateTask")
local NodeParser = require(pdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_bIsEndState = false
    self.m_method = false
    self.m_transitions = {}
end

function _M:release()
    _M.super.release(self)

    self.m_method = false
end

function _M:onLoading(version, agentType, properties)
    _M.super.onLoading(self, version, agentType, properties)

    for _, p in ipairs(properties) do
        local methodStr = p["Method"]
        local isEndStateStr = p["IsEndState"]

        if nil ~= methodStr then
            self.m_method = NodeParser.parseMethod(methodStr)
        elseif nil ~= isEndStateStr then
            self.m_bIsEndState = (isEndStateStr == "true")
        else
            -- _G.BEHAVIAC_ASSERT(0, "unrecognized property")
        end
    end
end

function _M:attach(pAttachment, bIsPrecondition, bIsEffector, bIsTransition)
    if bIsTransition then
        _G.BEHAVIAC_ASSERT(not bIsEffector and not bIsPrecondition, "Transition flag conficts with effector and precondition flag")

        local pTransition = pAttachment
        _G.BEHAVIAC_ASSERT(nil ~= pTransition, "Transition node cann't be nil")
        return table.insert(self.m_transitions, pTransition)
    else
        return _M.super.attach(self, pAttachment, bIsPrecondition, bIsEffector, bIsTransition)
    end
end

function _M:updateImpl(agent, tick, childStatus)
    return EBTStatus.BT_RUNNING
end

function _M:execute(agent)
    local status = EBTStatus.BT_RUNNING

    if self.m_method then
        self.m_method:run(agent)
    else
        status = self:updateImpl(agent, EBTStatus.BT_RUNNING)
    end

    return status
end

-- nextStateId holds the next state id if it returns running when a certain transition is satisfied
-- otherwise, it returns success or failure if it ends
function _M:update(agent, tick, nextStateId)
    nextStateId = -1

    -- when no method is specified(m_method == 0),
    -- 'updateImpl' is used to return the configured result status for both xml/bson and c#
    local status = self.execute(agent)

    if self.m_bIsEndState then
        status = EBTStatus.BT_SUCCESS
    else
        local bTransitioned, nextStateId = self.updateTransitions(self, agent, self, self.m_transitions, nextStateId, status)

        if bTransitioned then
            -- it will transition to another state, set result as success so as it exits
            status = EBTStatus.BT_SUCCESS
        end
    end

    return status
end

function _M.s_updateTransitions(agent, node, transitions, nextStateId, status)
    --_G.BEHAVIAC_UNUSED_VAR(node)
    local bTransitioned = false

    if transitions and #transitions > 0 then
        for _, transition in ipairs(transitions) do
            if transition:evaluate(agent, status) then
                nextStateId = transition.getTargetStateId()
                _G.BEHAVIAC_ASSERT(nextStateId ~= -1, "Invalid nextStateId")

                -- transition actions
                transition:applyEffects(agent, ENodePhase.E_BOTH)

--[[
#if !BEHAVIAC_RELEASE

                if (Config::IsLoggingOrSocketing()) {
                    CHECK_BREAKPOINT(agent, node, "transition", EAR_none)
                }

#endif
]]
                bTransitioned = true
                break
            end
        end
    end

    return bTransitioned, nextStateId
end

function _M:isEndState()
    return self.m_bIsEndState
end

function _M:isState()
    return true
end

function _M:isValid(agent, task)
    if not task:getNode() or not task:getNode():isState() then
        return false
    end

    return _M.super.isValid(agent, task)
end

function _M:createTask()
    return StateTask.new()
end

return _M