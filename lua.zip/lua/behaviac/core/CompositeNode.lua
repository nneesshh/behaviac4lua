--- Behaviac lib Component: composite node.
-- @module CompositeNode.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(pdir .. "enums")
local common = require(pdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local BranchNode = require(cwd .. "BranchNode")
local CompositeNode = class("CompositeNode", BranchNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("CompositeNode", CompositeNode)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("CompositeNode", "BranchNode")
local _M = CompositeNode

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_children         = {}
end

function _M:release()
    _M.super.release(self)

    for _, child in ipairs(self.m_children) do
        child:release()
    end
    self.m_children = {}
end

function _M:init(tick)
    _M.super.init(self, tick)
    _G.BEHAVIAC_ASSERT(self:getChildrenCount() > 0, "self:getChildrenCount() > 0")

    local childrenCount = self:getChildrenCount()
    for index = 1, childrenCount do
        local childNode = self:getChild(index)
        childNode:init(tick)
    end
end

function _M:traverse(childFirst, handler, agent, userData)
    if childFirst then
        for _, child in ipairs(self.m_children) do
            child:traverse(childFirst, handler, agent, userData)
        end
        handler(self, agent, userData)
    else
        if handler(self, agent, userData) then
            for _, child in ipairs(self.m_children) do
                child:traverse(childFirst, handler, agent, userData)
            end
        end
    end
end

function _M:copyTo(agent, target)
    _M.super.copyTo(self, agent, target)

    _G.BEHAVIAC_ASSERT(target:isCompositeNode(), "target:isCompositeNode()")
    target:setActiveChildIndex(agent, self:getActiveChildIndex(agent))

    _G.BEHAVIAC_ASSERT(#self.m_children > 0, "self.m_children > 0")
    _G.BEHAVIAC_ASSERT(#self.m_children == #target.m_children, "#self.m_children == #target.m_children")

    local count = #self.m_children
    for i = 1, count do
        local selfChild = self.m_children[i]
        local targetChild = target.m_children[i]
        selfChild:copyTo(agent, targetChild)
    end
end

function _M:setActiveChildIndex(agent, index)
    local curTick = agent:getCurrentTreeTick()
    curTick:setNodeMem("activeChildIndex", index, self)
end

function _M:getActiveChildIndex(agent)
    local curTick = agent:getCurrentTreeTick()
    return curTick:getNodeMem("activeChildIndex", self)
end

return _M