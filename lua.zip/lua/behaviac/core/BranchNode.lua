--- Behaviac lib Component: branch node.
-- @module BranchNode.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(pdir .. "enums")
local common = require(pdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local BaseNode = require(cwd .. "BaseNode")
local BranchNode = class("BranchNode", BaseNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("BranchNode", BranchNode)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("BranchNode", "BaseNode")
local _M = BranchNode

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:isBranchNode()
    return true
end

function _M:init(tick)
    _M.super.init(self, tick)
end

function _M:traverse(childFirst, handler, agent, userData)
	handler(self, agent, userData)
end

local function getIdHandler(node, agent, userData)
    local oldId = node:getId()

    if oldId == userData.id_ then
        userdata.node_ = node
        return false
    end

    return true
end

function _M:copyTo(agent, target)
    _M.super.copyTo(self, agent, target)

    if not target:isBranchNode() then
        Logging.error("[_M:copyTo()] node is not BranchNode")
        return
    end

    local curVisitingNode = self:getCurrentVisitingNode(agent)
    if curVisitingNode then
        local id = curVisitingNode:getId()
        local data = {id_ = id}
        target:traverse(true, getIdHandler, false, data)
        target:setCurrentVisitingNode(data.node_)
    end
end

function _M:execCurrentVisitingNode(agent, tick, childStatus)
    local curVisitingNode = self:getCurrentVisitingNode(agent)
    _G.BEHAVIAC_ASSERT(curVisitingNode)
    if curVisitingNode:getStatus() ~= EBTStatus.BT_RUNNING then
        Logging.error("[_M:execCurrentVisitingNode()] curVisitingNode status (%d) is not running", curVisitingNode:getStatus())
        return EBTStatus.BT_FAILURE
    end

    -- this->m_currentVisitingNode could be cleared in ::tick, to remember it        
    local status = tick:execWithChildStatus(curVisitingNode, agent, childStatus)
    
    -- give the handling back to parents if out of running
    if status ~= EBTStatus.BT_RUNNING then
        -- state must BT_SUCCESS orBT_FAILURE
        _G.BEHAVIAC_ASSERT(status == EBTStatus.BT_SUCCESS or status == EBTStatus.BT_FAILURE)
        _G.BEHAVIAC_ASSERT(curVisitingNode:getStatus(agent) == status)

        local parentBranch = curVisitingNode:getParent()
        self:setCurrentVisitingNode(agent, false)

        -- back track the parents until the branch
        while parentBranch do
            if parentBranch == self then
                status = parentBranch:update(agent, tick, status)
            else
                status = parentBranch:execWithChildStatus(agent, tick, status)
            end

            if status == EBTStatus.BT_RUNNING then
                return EBTStatus.BT_RUNNING
            end

            _G.BEHAVIAC_ASSERT(parentBranch == self or parentBranch.m_status == status)

            if parentBranch == self then
                break
            end

            parentBranch = parentBranch:getParent()
        end
    end

    return status
end

function _M:resumeBranch(agent, status)
    local curVisitingNode = self:getCurrentVisitingNode(agent)
    if not curVisitingNode then
        Logging.error("[_M:resumeBranch()] no current visiting node")
        return EBTStatus.BT_INVALID
    end

    if not(status == EBTStatus.BT_SUCCESS or status == EBTStatus.BT_FAILURE) then
        Logging.error("[_M:resumeBranch()] error status %", status)
        return EBTStatus.BT_INVALID
    end

    local parent = false
    local _tNode = curVisitingNode
    if _tNode:isManagingChildrenAsSubTrees() then
        parent = curVisitingNode
    else
        parent = curVisitingNode:getParent()
    end

    -- clear it as it ends and the next exec might need to set it
    self:setCurrentVisitingNode(tick, false)
    return parent:execWithChildStatus(agent, status)
end

function _M:onEvent(agent, eventName, eventParams)
    if self:hasEvents() then
        local bGoOn = true

        local curVisitingNode = self:getCurrentVisitingNode(agent)
        if curVisitingNode then
            bGoOn = self:onEventCurrentVisitingNode(agent, eventName, eventParams)
        end

        if bGoOn then
            bGoOn = _M.super.onEvent(self, agent, eventName, eventParams)
        end
    end

    return true
end

function _M:onEnter()
    return true
end

function _M:onExit()
    -- do nothing
end

function _M:onEventCurrentVisitingNode(agent, eventName, eventParams)
    local curVisitingNode = self:getCurrentVisitingNode(tick)
    if curVisitingNode then
        local s = curVisitingNode:getStatus(tick)
        _G.BEHAVIAC_ASSERT(s == EBTStatus.BT_RUNNING and self:hasEvents(), "[_M:onEventCurrentVisitingNode()] invalid status=%d", s)

        local bGoOn = self.m_currentVisitingNode:onEvent(agent, eventName, eventParams)
        
        -- give the handling back to parents
        if bGoOn and self.m_currentVisitingNode then
            parentBranch = self.m_currentVisitingNode:getParent()

            -- back track the parents until the branch
            while parentBranch and parentBranch ~= self do
                _G.BEHAVIAC_ASSERT(parentBranch:getStatus() == EBTStatus.BT_RUNNING, "[_M:onEventCurrentVisitingNode()] invalid status=%d", parentBranch:getStatus())

                bGoOn = parentBranch:onEvent(agent, eventName, eventParams)
                if not bGoOn then
                    return false
                end

                parentBranch = parentBranch:getParent()
            end
        end

        return bGoOn
    end

    return true
end

function _M:updateCurrent(agent, tick, childStatus)
    local status = EBTStatus.BT_INVALID
    if self.m_currentVisitingNode then
        return self:execCurrentVisitingNode(agent, tick, childStatus)
    else
        return self:update(agent, tick, childStatus)
    end
end

function _M:update(agent, tick, childStatus)
    return EBTStatus.BT_SUCCESS
end


-- See behaviortree_task.cpp
--     void BranchTask::SetCurrentTask(BehaviorTask* task)
function _M:setCurrentVisitingNode(agent, visitingNode)
    local curTick = agent:getCurrentTreeTick()
    local pLastVisitingNode = self:getCurrentVisitingNode(agent)
    if visitingNode then
        -- if the leaf node is running, then the leaf's parent node is also as running,
        -- the leaf is set as the tree's current task instead of its parent
        if not pLastVisitingNode then
            _M.super.setCurrentVisitingNode(self, agent, visitingNode)

            -- print("node", visitingNode.__name)
            visitingNode:setHasManagingParent(true)
        end
    else
        if self.m_status ~= EBTStatus.BT_RUNNING then
            _M.super.setCurrentVisitingNode(self, agent, visitingNode)
        end
    end
end

return _M