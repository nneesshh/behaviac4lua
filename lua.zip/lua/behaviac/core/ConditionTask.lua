--- Behaviac lib Component: condition task.
-- @module ConditionTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(pdir .. "enums")
local common = require(pdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local LeafTask = require(cwd .. "LeafTask")
local ConditionTask = class("ConditionTask", LeafTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("ConditionTask", ConditionTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("ConditionTask", "LeafTask")
local _M = ConditionTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:onEnter(agent)
    return true
end

function _M:onExit(agent, status)
end

function _M:update(agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(self:getNode():isCondition(), "[_M:update()] self:getNode():isCondition")

    local pConditionNode = self:getNode()
    if pConditionNode:evaluate(agent) then
        return EBTStatus.BT_SUCCESS
    else
        return EBTStatus.BT_FAILURE
    end
end

return _M