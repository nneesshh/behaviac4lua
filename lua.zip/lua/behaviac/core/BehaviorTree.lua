--- Behaviac lib Component: behavior tree.
-- @module BehaviorTree.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(pdir .. "enums")
local common = require(pdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local SingleChildNode = require(cwd .. "SingleChildNode")
local BehaviorTree = class("BehaviorTree", SingleChildNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("BehaviorTree", BehaviorTree)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("BehaviorTree", "SingleChildNode")
local _M = BehaviorTree

local NodeParser = require(pdir .. "parser.NodeParser")
local NodeLoader = require(pdir .. "parser.NodeLoader")

local AgentMeta = require(pdir .. "agent.AgentMeta")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
    
    self.m_name              = ""
    self.m_behaviorTreePath  = ""
    self.m_domains           = ""
    self.m_bIsFSM            = false
    self.m_localProps        = {}
end

function _M:release()
    _M.super.release(self)
end

function _M:onLoading(version, agentType, properties)
    _M.super.onLoading(self.version, agentType, properties)

    for _, p in pairs(properties) do
        local domainsStr = p[constBaseKeyStrDef.kStrDomains]
        local descriptorRefsStr = p[constBaseKeyStrDef.kStrDescriptorRefs]

        if nil ~= domainsStr then
            self.m_domains = domainsStr
        elseif nil ~= descriptorRefsStr then
            -- do nothing
        else
            -- do nothing
        end
    end
end

function _M:getName()
    return self.m_name
end

function _M:setName(name)
    self.m_name = name
end

function _M:getBehaviorTreePath()
    return self.m_behaviorTreePath
end

function _M:setBehaviorTreePath(path)
    self.m_behaviorTreePath = path
end

function _M:getDomains()
    return self.m_domains
end

function _M:setDomains(domains)
    self.m_domains = domains
end

function _M:isFSM()
    return self.m_bIsFSM
end

function _M:load(treeData, behaviorTreePath)
    -- behavior node
    local behaviorEntry = treeData[constBaseKeyStrDef.kStrBehavior]
    if not behaviorEntry then
        Logging.error("[_M:load()] file(%s) is invalid!!!", path)
        return
    end

    local name = behaviorEntry[constBaseKeyStrDef.kStrName]
    local agentType = behaviorEntry[constBaseKeyStrDef.kStrAgentType]
    local version = tonumber(behaviorEntry[constBaseKeyStrDef.kStrVersion]) or 0

    behaviorTreePath = behaviorTreePath or AgentMeta.getBehaviorTreePath(name)

    self:setName(name)
    self:setBehaviorTreePath(behaviorTreePath)
    self:setClassNameString("BehaviorTree")
    self:setId(0xffffffff)

    if behaviorEntry["fsm"] == "true" then
        self.m_bIsFSM = true
    end

    --
    NodeLoader.loadPropertiesParsAttachmentsChildren(self, version, agentType, behaviorEntry)
    return true
end

function _M:loadLocal(version, agentType, parNode)
    local name = parNode[constBaseKeyStrDef.kStrName]
    local type = parNode[constBaseKeyStrDef.kStrType]
    local value = parNode[constBaseKeyStrDef.kStrValue]

    self:addLocal(agentType, type, name, value)
end

function _M:addLocal(agentType, typeName, name, valueStr)
    self.m_localProps[name] = common.readBasicType(typeName, valueStr)
end

function _M:addPar(agentType, typeName, name, valueStr)
    self:addLocal(agentType, typeName, name, valueStr)
end

function _M:isManagingChildrenAsSubTrees()
    return true
end

function _M:isBehaviorTree()
    return true
end

--
-- Blackboard: init
--
function _M:init(tick)
    _M.super.init(self, tick)

    
end

function _M:resume(agent, status)
    return _M.super.resumeBranch(self, agent, status)
end

function _M:onEnter(agent)
    local curTick = agent:getCurrentTreeTick()
    agent:pushExecutingTreeTick(curTick)
    return true
end

function _M:onExit(agent, status)
    agent:popExecutingTreeTick()
    return _M.super.onExit(self, agent, status)
end

function _M:updateCurrent(agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(self:isBehaviorTree(), "[_M:updateCurrent()] m_node:isBehaviorTree failed")

    local status = EBTStatus.BT_RUNNING
    if self:isFSM() then
        status = self:update(agent, tick, childStatus)
    else
        status = _M.super.updateCurrent(self, agent, tick, childStatus)
    end

    return status
end

function _M:update(agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(self.m_root, "[_M:update()] self.m_root is false")

    if childStatus ~= EBTStatus.BT_RUNNING then
        return childStatus
    end

    local status = EBTStatus.BT_INVALID
    self:setEndStatus(agent, EBTStatus.BT_INVALID)

    status = _M.super.update(self, agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(status ~= EBTStatus.BT_INVALID, "[_M:update()] status == EBTStatus.BT_INVALID")
    
    -- When the End node takes effect, it always returns BT_RUNNING
    -- and m_endStatus should always be BT_SUCCESS or BT_FAILURE
    local endStatus = self:getEndStatus()
    if status == EBTStatus.BT_RUNNING and endStatus ~= EBTStatus.BT_INVALID then
        tick:endDo(self, agent, endStatus)
        return endStatus
    end

    return status
end

function _M:setEndStatus(agent, status)
    local curTick = agent:getCurrentTreeTick()
    curTick:setNodeMem("endStatus", status, self)
end

function _M:getEndStatus(agent)
    local curTick = agent:getCurrentTreeTick()
    return curTick:getNodeMem("endStatus", status, self)
end

return _M