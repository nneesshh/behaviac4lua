--- Behaviac lib Component: decorator task.
-- @module DecoratorTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(pdir .. "enums")
local common = require(pdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local SingleChildNode = require(cwd .. "SingleChildNode")
local DecoratorTask = class("DecoratorTask", SingleChildNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorTask", DecoratorTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorTask", "SingleChildNode")
local _M = DecoratorTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_bDecorateWhenChildEnds = false
end

function _M:release()
    _M.super.release(self)
end

-- 
function _M:init(node)
    _M.super.init(self, node)

    self.m_bDecorateWhenChildEnds = node.m_bDecorateWhenChildEnds
end

function _M:onEnter(agent)
    return true
end

function _M:update(agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(self.m_node:isDecorator(), "[_M:update()] isDecorator")
    local pNode  = self.m_node
    local status = EBTStatus.BT_INVALID
    if childStatus ~= EBTStatus.BT_RUNNING then
        status = childStatus
        if not pNode.m_bDecorateWhenChildEnds or status ~= EBTStatus.BT_RUNNING then
            local result = self:decorate(status)
            if result ~= EBTStatus.BT_RUNNING then
                return result
            end
            
            return EBTStatus.BT_RUNNING
        end
    end

    status = _M.super.update(self, agent, tick, childStatus)
    if not pNode.m_bDecorateWhenChildEnds or status ~= EBTStatus.BT_RUNNING then
        local result = self:decorate(status)
        if result ~= EBTStatus.BT_RUNNING then
            return result
        end
    end
    return EBTStatus.BT_RUNNING
end

-- called when the child's exec returns success or failure.
-- please note, it is not called if the child's exec returns running
function _M:decorate(status)
    -- _G.BEHAVIAC_UNUSED_VAR status
    Logging.error("derived class must be rewrite _M:decorate")
    return EBTStatus.BT_RUNNING
end

return _M