--- Behaviac lib Component: condition node.
-- @module Condition.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(pdir .. "enums")
local common = require(pdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local BaseNode = require(cwd .. "BaseNode")
local Condition = class("Condition", BaseNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("Condition", Condition)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("Condition", "BaseNode")
local _M = Condition

local ConditionTask = require(cwd .. "ConditionTask")
local NodeParser = require(pdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_opl      = false
    self.m_opr      = false
    self.m_operator = EOperatorType.E_EQUAL
end

function _M:release()
    _M.super.release(self)

    self.m_opl      = false
    self.m_opr      = false
end

function _M:onLoading(version, agentType, properties)
    _M.super.onLoading(self, version, agentType, properties)

    for _, p in ipairs(properties) do
        local opStr = p["Operator"]
        local opLeft = p["Opl"]
        local opRight = p["Opr"]

        if nil ~= opStr then
            self.m_operator = NodeParser.parseOperatorType(opStr)
        elseif nil ~= opLeft then
            local pParenthesis = string.find(opLeft, '%(')
            if not pParenthesis then
                self.m_opl = NodeParser.parseProperty(opLeft)
            else
                self.m_opl = NodeParser.parseMethod(opLeft)
            end
        elseif nil ~= opRight then
            local pParenthesis = string.find(opRight, '%(')
            if not pParenthesis then
                self.m_opr = NodeParser.parseProperty(opRight)
            else
                self.m_opr = NodeParser.parseMethod(opRight)
            end
        else
            -- maybe others
        end
    end
end

function _M:evaluate(agent)
    if self.m_opl and self.m_opr then
        return self.m_opl:compare(agent, self.m_opr, self.m_operator)
    else
        local result = self:updateImpl(agent, EBTStatus.BT_INVALID)
        return result == EBTStatus.BT_SUCCESS
    end
end

function _M:cleanUp()
    Logging.error("[_M:cleanUp()]")
end

function _M:isCondition()
    return true
end

function _M:isValid(agent, task)
    if not task:getNode() or not task:getNode():isCondition() then
        return false
    end
    return _M.super.isValid(self, agent, task)
end

function _M:createTask()
    return ConditionTask.new()
end

return _M