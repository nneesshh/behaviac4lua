--- Behaviac lib Component: every time decorator node.
-- @module DecoratorEveryTime.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreDecoratorPhase        = enums.EPreDecoratorPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
-- Execute intervally
local DecoratorTime = require(cwd .. "DecoratorTime")
local DecoratorEveryTime = class("DecoratorEveryTime", DecoratorTime)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorEveryTime", DecoratorEveryTime)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorEveryTime", "DecoratorTime")
local _M = DecoratorEveryTime

local DecoratorEveryTimeTask = require(cwd .. "DecoratorEveryTimeTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_time = false
end

function _M:release()
    _M.super.release(self)
end

function _M:createTask()
    return DecoratorEveryTimeTask.new()
end

return _M