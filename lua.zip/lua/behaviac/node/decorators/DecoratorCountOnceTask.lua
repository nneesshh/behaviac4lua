--- Behaviac lib Component: decorator count once task.
-- @module DecoratorCountOnceTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local DecoratorCountTask = require(cwd .. "DecoratorCountTask")
local DecoratorCountOnceTask = class("DecoratorCountOnceTask", DecoratorCountTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorCountOnceTask", DecoratorCountOnceTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorCountOnceTask", "DecoratorCountTask")
local _M = DecoratorCountOnceTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_bInited  = false
    self.m_bRunOnce = false
end

function _M:release()
    _M.super.release(self)
end

function _M:copyTo(target)
    _M.super.copyTo(self, target)
    _G.BEHAVIAC_ASSERT(target:isDecoratorCountOnceTask(), "[_M:copyTo()] target:isDecoratorCountOnceTask")

    target.m_bInited = self.m_bInited
end

function _M:onEnter(agent)
    if self.m_bRunOnce then
        return false
    end

    if self.m_status == EBTStatus.BT_RUNNING then
        return true
    end
    if self.m_node:checkIfReInit(agent) then
        self.m_bInited = false
    end

    if not self.m_bInited then
        self.m_bInited = true
        local count = self:getNode():getCount(agent) or 0
        self.m_n = count
        _G.BEHAVIAC_ASSERT(self.m_n > 0, "[_M:onEnter()] false self.m_n > 0")
    end

    -- if self.m_n is -1, it is endless
    if self.m_n > 0 then
        self.m_n = self.m_n - 1
        return true
    elseif self.m_n == 0 then
        self.m_bRunOnce = true
        return false
    elseif self.m_n == -1 then
        self.m_bRunOnce = true
        return true
    end
    _G.BEHAVIAC_ASSERT(false, "[_M:onEnter()] false")
    return false
end

function _M:decorate(status)
    _G.BEHAVIAC_ASSERT(self.m_n >= 0 or self.m_n == -1, "[_M:decorate()] self.m_n >= 0 or self.m_n == -1")
    return status
end

function _M:isDecoratorCountOnceTask()
    return true
end

return _M