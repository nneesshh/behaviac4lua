--- Behaviac lib Component: decorator frames task.
-- @module DecoratorFramesTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local DecoratorTask = require(ppdir .. "core.DecoratorTask")
local DecoratorFramesTask = class("DecoratorFramesTask", DecoratorTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorFramesTask", DecoratorFramesTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorFramesTask", "DecoratorTask")
local _M = DecoratorFramesTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
    
    self.m_start    = 0
    self.m_frames   = 0
end

function _M:release()
    _M.super.release(self)
end

function _M:copyTo(target)
    _G.BEHAVIAC_ASSERT(target:isDecoratorFramesTask(), "[_M:copyTo()] target:isDecoratorFramesTask")
    _M.super.copyTo(self, target)

    target.m_start  = self.m_start
    target.m_frames = self.m_frames
end

function _M:onEnter(agent)
    _M.super.onEnter(agent)

    self.m_start = common.getFrames()
    self.m_frames = self:getNode():getFrames(agent) or 0

    return self.m_frames > 0
end

function _M:isDecoratorFramesTask()
    return true
end

function _M:decorate(status)
    if redoGetFrameSinceStartup() - self.m_start + 1 >= self.m_frames then
        return EBTStatus.BT_SUCCESS
    end

    return EBTStatus.BT_RUNNING
end

return _M