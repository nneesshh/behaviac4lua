--- Behaviac lib Component: decorator not task.
-- @module DecoratorNotTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local DecoratorTask = require(ppdir .. "core.DecoratorTask")
local DecoratorNotTask = class("DecoratorNotTask", DecoratorTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorNotTask", DecoratorNotTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorNotTask", "DecoratorTask")
local _M = DecoratorNotTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:decorate(status)
    if status == EBTStatus.BT_FAILURE then
        return EBTStatus.BT_SUCCESS
    end

    if status == EBTStatus.BT_SUCCESS then
        return EBTStatus.BT_FAILURE
    end

    return status
end

return _M