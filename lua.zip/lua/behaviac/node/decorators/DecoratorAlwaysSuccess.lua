--- Behaviac lib Component: always success decorator node.
-- @module DecoratorAlwaysSuccess.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreDecoratorPhase        = enums.EPreDecoratorPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
-- No matter what child return. DecoratorAlwaysSuccess always return Success. it can only has one child node.
local Decorator = require(ppdir .. "core.Decorator")
local DecoratorAlwaysSuccess = class("DecoratorAlwaysSuccess", Decorator)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorAlwaysSuccess", DecoratorAlwaysSuccess)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorAlwaysSuccess", "Decorator")
local _M = DecoratorAlwaysSuccess

local DecoratorAlwaysSuccessTask = require(cwd .. "DecoratorAlwaysSuccessTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:isDecoratorAlwaysSuccess()
    return true
end

function _M:isValid(agent, task)
    if not task:getNode() or not task:getNode():isDecoratorAlwaysSuccess() then
        return false
    end

    return _M.super.isValid(self, agent, task)
end

function _M:createTask()
    return DecoratorAlwaysSuccessTask.new()
end

return _M