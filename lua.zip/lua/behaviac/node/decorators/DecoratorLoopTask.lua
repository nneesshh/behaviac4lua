--- Behaviac lib Component: decorator loop task.
-- @module DecoratorLoopTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local DecoratorCountTask = require(cwd .. "DecoratorCountTask")
local DecoratorLoopTask = class("DecoratorLoopTask", DecoratorCountTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorLoopTask", DecoratorLoopTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorLoopTask", "DecoratorCountTask")
local _M = DecoratorLoopTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:update(agent, tick, childStatus)    
    _G.BEHAVIAC_ASSERT(self.m_node and self.m_node:isDecoratorLoop(), "[_M:update()] self.m_node:isDecoratorLoop")
    if self.m_node.m_bDoneWithinFrame then
        _G.BEHAVIAC_ASSERT(self.m_n >= 0, "[_M:update()] self.m_n")
        _G.BEHAVIAC_ASSERT(self.m_root, "[_M:update()] self.m_root")

        local status = EBTStatus.BT_INVALID
        for i = 1, self.m_n do
            status = tick:execWithChildStatus(self.m_root, agent, childStatus)
            if self.m_node.m_bDecorateWhenChildEnds then
                while status == EBTStatus.BT_RUNNING do
                    status = _M.super.update(self, agent, tick, childStatus)
                end
            end

            if status == EBTStatus.BT_FAILURE then
                return EBTStatus.BT_FAILURE
            end
        end

        return EBTStatus.BT_SUCCESS
    end
    
    return _M.super.update(self, agent, tick, childStatus)
end

--
function _M:decorate(status)
    if self.m_n > 0 then
        self.m_n = self.m_n - 1
        if self.m_n == 0 then
            return EBTStatus.BT_SUCCESS
        end
        return EBTStatus.BT_RUNNING
    end

    if self.m_n == -1 then
        return EBTStatus.BT_RUNNING
    end

    _G.BEHAVIAC_ASSERT(self.m_n == 0, "[_M:decorate()] self.m_n == 0")
    return EBTStatus.BT_SUCCESS
end

return _M