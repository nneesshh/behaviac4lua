--- Behaviac lib Component: decorator count limit task.
-- @module DecoratorCountLimitTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local DecoratorCountTask = require(cwd .. "DecoratorCountTask")
local DecoratorCountLimitTask = class("DecoratorCountLimitTask", DecoratorCountTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorCountLimitTask", DecoratorCountLimitTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorCountLimitTask", "DecoratorCountTask")
local _M = DecoratorCountLimitTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_bInited = false
end

function _M:release()
    _M.super.release(self)
end

function _M:copyTo(target)
    _M.super.copyTo(self, target)
    _G.BEHAVIAC_ASSERT(target:isDecoratorCountLimitTask(), "[_M:copyTo()] target:isDecoratorCountLimitTask")

    target.m_bInited = self.m_bInited
end

function _M:onEnter(agent)
    if self.m_node:checkIfReInit(agent) then
        self.m_bInited = false
    end

    if not self.m_bInited then
        self.m_bInited = true
        local count = self:getNode():getCount(agent) or 0
        self.m_n = count
    end

    -- if self.m_n is -1, it is endless
    if self.m_n > 0 then
        self.m_n = self.m_n - 1
        return true
    elseif self.m_n == 0 then
        return false
    elseif self.m_n == -1 then
        return true
    end
    _G.BEHAVIAC_ASSERT(false, "[_M:onEnter()] false")
    return false
end

function _M:decorate(status)
    _G.BEHAVIAC_ASSERT(self.m_n >= 0 or self.m_n == -1, "[_M:decorate()] self.m_n >= 0 or self.m_n == -1")
    return status
end

function _M:isDecoratorCountLimitTask()
    return true
end

return _M