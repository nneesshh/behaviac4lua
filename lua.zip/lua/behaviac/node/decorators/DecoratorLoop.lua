--- Behaviac lib Component: failure until decorator node.
-- @module DecoratorLoop.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreDecoratorPhase        = enums.EPreDecoratorPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
-- DecoratorLoop can be set a integer Count value. It increases inner count value when it updates.
-- It always return Running until inner count less equal than integer Count value. Or returns the child
-- value. It always return Running when the count limit equal to -1.
local DecoratorCount = require(cwd .. "DecoratorCount")
local DecoratorLoop = class("DecoratorLoop", DecoratorCount)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorLoop", DecoratorLoop)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorLoop", "DecoratorCount")
local _M = DecoratorLoop

local DecoratorLoopTask = require(cwd .. "DecoratorLoopTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_bDoneWithinFrame = false
end

function _M:release()
    _M.super.release(self)
end

function _M:onLoading(version, agentType, properties)
    _M.super.onLoading(self, version, agentType, properties)

    for _, p in ipairs(properties) do
        local doneWithinFrameStr = p["DoneWithinFrame"]

        if nil ~= doneWithinFrameStr then
            self.m_bDoneWithinFrame = (doneWithinFrameStr == "true")
        end
    end   
end

function _M:isDecoratorLoop()
    return true
end

function _M:isValid(agent, task)
    if not task:getNode() or not task:getNode():isDecoratorLoop() then
        return false
    end

    return _M.super.isValid(self, agent, task)
end

function _M:createTask()
    return DecoratorLoopTask.new()
end

return _M