--- Behaviac lib Component: time decorator node.
-- @module DecoratorTime.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreDecoratorPhase        = enums.EPreDecoratorPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
-- It returns Running result until it reaches the time limit specified, no matter which
-- value its child return. Or return the child's value.
local Decorator = require(ppdir .. "core.Decorator")
local DecoratorTime = class("DecoratorTime", Decorator)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorTime", DecoratorTime)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorTime", "Decorator")
local _M = DecoratorTime

local DecoratorTimeTask = require(cwd .. "DecoratorTimeTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_time = false
end

function _M:release()
    _M.super.release(self)
    
    self.m_time = false
end

function _M:onLoading(version, agentType, properties)
    _M.super.onLoading(self, version, agentType, properties)

    for _, p in ipairs(properties) do
        local timeStr = p["Time"]

        if nil ~= timeStr then
            local pParenthesis = string.find(timeStr, "%(")
            if not pParenthesis then
                self.m_time = BehaviorParseFactory.parseProperty(timeStr)
            else
                self.m_time = BehaviorParseFactory.parseMethod(timeStr)
            end
        end
    end
end

function _M:getTime(agent)
    if self.m_time then
        return self.m_time
    end
    return agent:getTime()
end

function _M:isDecoratorTime()
    return true
end

function _M:createTask()
    return DecoratorTimeTask.new()
end

return _M