--- Behaviac lib Component: decorator every time task.
-- @module DecoratorEveryTimeTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local DecoratorTimeTask = require(cwd .. "DecoratorTimeTask")
local DecoratorEveryTimeTask = class("DecoratorEveryTimeTask", DecoratorTimeTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorEveryTimeTask", DecoratorEveryTimeTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorEveryTimeTask", "DecoratorTimeTask")
local _M = DecoratorEveryTimeTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_start    = 0
    self.m_time     = 0
    self.m_bInited  = false
end

function _M:release()
    _M.super.release(self)
end

function _M:copyTo(target)
    _M.super.copyTo(self, target)
    _G.BEHAVIAC_ASSERT(target:isDecoratorEveryTimeTask(), "[_M:copyTo()] target:isDecoratorEveryTimeTask")
    target.m_start      = self.m_start
    target.m_time       = self.m_time
end

function _M:checkTime(agent)
    local time = comm.getColock()
    if time - self.m_start >= self.m_time then
        self.m_start = time
        return true
    end

    return false
end

function _M:onEnter(agent)
    if self.m_bInited then
        if self.m_status == EBTStatus.BT_RUNNING then
            return true
        else
            return self:checkTime(agent)
        end
    end

    if _M.super.onEnter(self, agent) then
        self.m_bInited = true
        return self:checkTime(agent)
    else
        return false
    end
end

function _M:isDecoratorEveryTimeTask()
    return true
end

function _M:decorate(status)
    return status
end

return _M