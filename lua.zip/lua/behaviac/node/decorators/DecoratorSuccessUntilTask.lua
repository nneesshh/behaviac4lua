--- Behaviac lib Component: decorator success until task.
-- @module DecoratorSuccessUntilTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local DecoratorCountTask = require(cwd .. "DecoratorCountTask")
local DecoratorSuccessUntilTask = class("DecoratorSuccessUntilTask", DecoratorCountTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorSuccessUntilTask", DecoratorSuccessUntilTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorSuccessUntilTask", "DecoratorCountTask")
local _M = DecoratorSuccessUntilTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:onReset(agent)
    self.m_n = 0
end

function _M:onEnter(agent)
    -- don't reset the m_n if it is restarted
    if self.m_n == 0 then
        local count = self:getNode():getCount(agent) or 0
        if count == 0 then
            return false
        end
        self.m_n = count
    else
        -- do nothing
    end

    return true
end

function _M:decorate(status)
    if self.m_n > 0 then
        self.m_n = self.m_n - 1
        if self.m_n == 0 then
            return EBTStatus.BT_FAILURE
        end
        return EBTStatus.BT_SUCCESS
    end

    if self.m_n == -1 then
        return EBTStatus.BT_SUCCESS
    end

    _G.BEHAVIAC_ASSERT(self.m_n == 0, "[_M:decorate()] self.m_n == 0")
    return EBTStatus.BT_FAILURE
end

return _M