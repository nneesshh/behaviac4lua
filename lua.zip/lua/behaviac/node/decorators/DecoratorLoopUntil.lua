--- Behaviac lib Component: loop until decorator node.
-- @module DecoratorLoopUntil.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreDecoratorPhase        = enums.EPreDecoratorPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
-- DecoratorLoopUntil node always return Failure until it reaches a specified number of count.
-- when reach time exceed the count specified return Success. If the specified number of count
-- is -1, then always return failed
-- Returns BT_FAILURE for the specified number of iterations, then returns BT_SUCCESS after that
local DecoratorCount = require(cwd .. "DecoratorCount")
local DecoratorLoopUntil = class("DecoratorLoopUntil", DecoratorCount)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorLoopUntil", DecoratorLoopUntil)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorLoopUntil", "DecoratorCount")
local _M = DecoratorLoopUntil

local DecoratorLoopUntilTask = require(cwd .. "DecoratorLoopUntilTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_until = false
end

function _M:release()
    _M.super.release(self)
end

function _M:onLoading(version, agentType, properties)
    _M.super.onLoading(self, version, agentType, properties)

    for _, p in ipairs(properties) do
        local untilStr = p["Until"]

        if nil ~= untilStr then
            self.m_until = (untilStr == "true")
        end
    end
end

function _M:createTask()
    return DecoratorLoopUntilTask.new()
end

return _M