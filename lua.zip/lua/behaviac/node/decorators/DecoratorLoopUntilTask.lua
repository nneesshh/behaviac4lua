--- Behaviac lib Component: decorator loop until task.
-- @module DecoratorLoopUntilTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local DecoratorCountTask = require(cwd .. "DecoratorCountTask")
local DecoratorLoopUntilTask = class("DecoratorLoopUntilTask", DecoratorCountTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorLoopUntilTask", DecoratorLoopUntilTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorLoopUntilTask", "DecoratorCountTask")
local _M = DecoratorLoopUntilTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:decorate(status)
    if self.m_n > 0 then
        self.m_n = self.m_n - 1
    end

    if self.m_n == 0 then
        return EBTStatus.BT_SUCCESS
    end

    _G.BEHAVIAC_ASSERT(self:getNode() and self:getNode():isDecoratorLoopUntil(), "[_M:decorate()] self:getNode():isDecoratorLoopUntil")
    local pDecoratorLoopUntil = self:getNode()
    if pDecoratorLoopUntil.m_until then
        if status == EBTStatus.BT_SUCCESS then
            return EBTStatus.BT_SUCCESS
        end
    else
        if status == EBTStatus.BT_FAILURE then
            return EBTStatus.BT_FAILURE
        end
    end

    return EBTStatus.BT_RUNNING
end

return _M