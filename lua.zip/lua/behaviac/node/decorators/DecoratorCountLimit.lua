--- Behaviac lib Component: count limit decorator node.
-- @module DecoratorCountLimit.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreDecoratorPhase        = enums.EPreDecoratorPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
-- DecoratorCountLimit can be set a integer Count limit value. DecoratorCountLimit node tick its child until
-- inner count less equal than count limit value. Whether node increase inner count depend on
-- the return value of its child when it updates. if DecorateChildEnds flag is true, node increase count
-- only when its child node return value is Success or Failure. The inner count will never reset until
-- attachment on the node evaluate true.
local DecoratorCount = require(cwd .. "DecoratorCount")
local DecoratorCountLimit = class("DecoratorCountLimit", DecoratorCount)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("DecoratorCountLimit", DecoratorCountLimit)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("DecoratorCountLimit", "DecoratorCount")
local _M = DecoratorCountLimit

local DecoratorCountLimitTask = require(cwd .. "DecoratorCountLimitTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:checkIfReInit(agent)
    return self:evaluteCustomCondition(agent)
end

function _M:isDecoratorCountLimit()
    return true
end

function _M:isValid(agent, task)
    if not task:getNode() or not task:getNode():isDecoratorCountLimit() then
        return false
    end

    return _M.super.isValid(self, agent, task)
end

function _M:createTask()
    return DecoratorCountLimitTask.new()
end

return _M