--- Behaviac lib Component: sequence task.
-- @module SequenceTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local CompositeNode = require(ppdir .. "core.CompositeNode")
local SequenceTask = class("SequenceTask", CompositeNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("SequenceTask", SequenceTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("SequenceTask", "CompositeNode")
local _M = SequenceTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:onEnter(agent)
    self.m_activeChildIndex = 1
    return true
end

function _M:update(agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(self.m_activeChildIndex <= #self.m_children, "[_M:update()] self.m_activeChildIndex <= #self.m_children")

    local outStatus, outActiveChildIndex = self.m_node:sequenceUpdate(agent, tick, childStatus, self.m_activeChildIndex, self.m_children)
    self.m_activeChildIndex = outActiveChildIndex
    return outStatus
end

return _M