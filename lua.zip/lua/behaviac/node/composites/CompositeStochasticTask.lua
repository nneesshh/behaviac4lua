--- Behaviac lib Component: composite stochastic task.
-- @module CompositeStochasticTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local CompositeNode = require(ppdir .. "core.CompositeNode")
local CompositeStochasticTask = class("CompositeStochasticTask", CompositeNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("CompositeStochasticTask", CompositeStochasticTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("CompositeStochasticTask", "CompositeNode")
local _M = CompositeStochasticTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
    
    self.m_set = {}
end

function _M:release()
    _M.super.release(self)
end

function _M:copyTo(target)
    _M.super.copyTo(self, target)

    _G.BEHAVIAC_ASSERT(target:isCompositeStochasticTask(), "[_M:copyTo()] target:isCompositeStochasticTask")
    target.m_set = table.copy(self.m_set)
end

function _M:onEnter(agent)
    _G.BEHAVIAC_ASSERT(#self.m_children > 0, "[_M:onEnter()] #self.m_children > 0")

    self:randomChild(agent)
    self.m_activeChildIndex = 1
    return true
end

function _M:onExit(agent, status)
end

function _M:update(agent, tick, childStatus)
    local bFirst = true
    _G.BEHAVIAC_ASSERT(self.m_activeChildIndex ~= constInvalidChildIndex, "[_M:update()] self.m_activeChildIndex ~= constInvalidChildIndex")

    while true do
        local s = childStatus

        if not bFirst or s == EBTStatus.BT_RUNNING then
            local childIndex = self.m_set[self.m_activeChildIndex]
            local pBehavior  = self.m_children[childIndex]
            s = pBehavior:exec(agent)
        end

        bFirst = false
        -- If the child succeeds, or keeps running, do the same.
        if s ~= EBTStatus.BT_FAILURE then
            return s
        end
        -- Hit the end of the array, job done!
        self.m_activeChildIndex = self.m_activeChildIndex + 1

        if self.m_activeChildIndex > #self.m_children then
            return EBTStatus.BT_FAILURE
        end
    end
end

function _M:onExit(agent, status)
end

function _M:randomChild(agent)
    _G.BEHAVIAC_ASSERT(not self:getNode() or self:getNode():isCompositeStochastic(), "[_M:randomChild()] not self:getNode() or self:getNode():isCompositeStochastic")
    local pNode = self:getNode()

    local n = #self.m_children
    for i = 1, n do
        self.m_set[i] = i
    end

    for i = 1, n do
        local method = false
        if pNode then
            method = pNode.m_method
        end
        
        local index1 = math.ceil(n * common.getRandomValue(method, agent))
        _G.BEHAVIAC_ASSERT(index1 <= n)

        local index2 = math.ceil(n * common.getRandomValue(method, agent))
        _G.BEHAVIAC_ASSERT(index2 <= n)

        -- swap
        if index1 ~= index2 then
            local old = self.m_set[index1]
            self.m_set[index1] = self.m_set[index2]
            self.m_set[index2] = old
        end
    end
end

function _M:isCompositeStochasticTask()
    return true
end

return _M