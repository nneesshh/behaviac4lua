--- Behaviac lib Component: selector stochastic task.
-- @module SelectorStochasticTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local CompositeNode = require(ppdir .. "core.CompositeNode")
local SelectorStochasticTask = class("SelectorStochasticTask", CompositeNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("SelectorStochasticTask", SelectorStochasticTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("SelectorStochasticTask", "CompositeNode")
local _M = SelectorStochasticTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:update(agent, tick, childStatus)
    local bFirst = true
    _G.BEHAVIAC_ASSERT(self.m_activeChildIndex ~= constInvalidChildIndex, "[_M:update()] self.m_activeChildIndex ~= constInvalidChildIndex")

    -- Keep going until a child behavior says its running.
    while true do
        local s = childStatus
        if not bFirst or s == EBTStatus.BT_RUNNING then
            local childIndex = self.m_set[self.m_activeChildIndex]
            local pBehavior = self.m_children[childIndex]
            s = pBehavior:exec(agent)
        end

        bFirst = false
        -- If the child succeeds, or keeps running, do the same.
        if s ~= EBTStatus.BT_FAILURE then
            return s
        end

        -- Hit the end of the array, job done!
        self.m_activeChildIndex = self.m_activeChildIndex + 1
        if self.m_activeChildIndex > #self.m_children then
            return EBTStatus.BT_FAILURE
        end
    end
end

return _M