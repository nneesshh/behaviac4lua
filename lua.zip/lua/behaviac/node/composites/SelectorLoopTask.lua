--- Behaviac lib Component: selector loop task.
-- @module SelectorLoopTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local CompositeNode = require(ppdir .. "core.CompositeNode")
local SelectorLoopTask = class("SelectorLoopTask", CompositeNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("SelectorLoopTask", SelectorLoopTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("SelectorLoopTask", "CompositeNode")
local _M = SelectorLoopTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:copyTo(target)
    _M.super.copyTo(target)

    _G.BEHAVIAC_ASSERT(target:isSelectorLoopTask(), "[_M:copyTo()] target:isSelectorLoopTask")
    target.m_activeChildIndex = self.m_activeChildIndex
end

function _M:addChild(pBehaviorTask)
    _M.super.addChild(self, pBehaviorTask)
    _G.BEHAVIAC_ASSERT(pBehaviorTask:isWithPreconditionTask(), "[_M:addChild()] pBehaviorTask:isWithPreconditionTask")
end

function _M:onEnter(agent)
    self.m_activeChildIndex = constInvalidChildIndex
    return _M.super.onEnter(self, agent) 
end

function _M:updateCurrent(agent, tick, childStatus)
    return self:update(agent, tick, childStatus)
end

function _M:update(agent, tick, childStatus)
    local idx = 0

    if childStatus ~= EBTStatus.BT_RUNNING then
        _G.BEHAVIAC_ASSERT(self.m_activeChildIndex ~= constInvalidChildIndex, "[_M:update()] self.m_activeChildIndex ~= constInvalidChildIndex")
        if childStatus == EBTStatus.BT_SUCCESS then
            return EBTStatus.BT_SUCCESS
        elseif childStatus == EBTStatus.BT_FAILURE then
            -- the next for starts from (idx + 1), so that it starts from next one after this failed one
            idx = self.m_activeChildIndex
        else
            _G.BEHAVIAC_ASSERT(false)
        end
    end

    -- checking the preconditions and take the first action tree
    local index = -1
    for i = idx + 1, #self.m_children do
        local pSubTree = self.m_children[i]
        _G.BEHAVIAC_ASSERT(pSubTree:isWithPreconditionTask(), "[_M:update()] pSubTree:isWithPreconditionTask")
        local preBehaviorTask = pSubTree:preconditionNode()
        local status = tick:exec(preBehaviorTask, agent)
        if status == EBTStatus.BT_SUCCESS then
            index = i
            break
        end
    end

    -- clean up the current ticking action tree
    if index ~= -1 then
        if self.m_activeChildIndex ~= constInvalidChildIndex then
            local abortChild = self.m_activeChildIndex ~= index
            if not abortChild then
                local pSelectorLoop = self:getNode()
                _G.BEHAVIAC_ASSERT(pSelectorLoop, "[_M:update()] pSelectorLoop")

                if pSelectorLoop ~= nil then
                    abortChild = pSelectorLoop.m_bResetChildren
                end
            end

            if abortChild then
                local pCurrentSubTree = self.m_children[self.m_activeChildIndex]
                _G.BEHAVIAC_ASSERT(pCurrentSubTree:isWithPreconditionTask(), "[_M:update()] pCurrentSubTree:isWithPreconditionTask")
                pCurrentSubTree:abort(agent)
            end
        end

        local i = index
        for i = index, #self.m_children do
            -- WithPreconditionTask
            local pSubTree = self.m_children[i]
            _G.BEHAVIAC_ASSERT(pSubTree:isWithPreconditionTask(), "[_M:update()] pSubTree:isWithPreconditionTask")

            if i >= index then
                local pre = pSubTree:preconditionNode()
                local status = pre:exec(agent)

                -- to search for the first one whose precondition is success
                if status == EBTStatus.BT_SUCCESS then
                    local action = pSubTree:actionNode()
                    local s = action:exec(agent)
        
                    if s == EBTStatus.BT_RUNNING then
                        self.m_activeChildIndex = i
                        pSubTree.m_status = EBTStatus.BT_RUNNING
                        return s
                    else
                        pSubTree.m_status = s
                        if s ~= EBTStatus.BT_FAILURE then
                            -- THE ACTION failed, to try the next one
                            _G.BEHAVIAC_ASSERT(s == EBTStatus.BT_RUNNING or s == EBTStatus.BT_SUCCESS, "[_M:update()] s == EBTStatus.BT_RUNNING or s == EBTStatus.BT_SUCCESS")
                            return s
                        end
                    end
                end
            end
        end
    end
    return EBTStatus.BT_FAILURE
end

function _M:isSelectorLoopTask()
    return true
end

return _M