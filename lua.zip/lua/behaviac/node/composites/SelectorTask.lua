--- Behaviac lib Component: selector task.
-- @module SelectorTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local CompositeNode = require(ppdir .. "core.CompositeNode")
local SelectorTask = class("SelectorTask", CompositeNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("SelectorTask", SelectorTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("SelectorTask", "CompositeNode")
local _M = SelectorTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:onEnter(agent)
    _G.BEHAVIAC_ASSERT(#self.m_children > 0, "[_M:onEnter()] #self.m_children > 0")
    self.m_activeChildIndex = 1
    return true
end

function _M:onExit(agent, status)
end

function _M:update(agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(self.m_activeChildIndex <= #self.m_children, "[_M:update()] self.m_activeChildIndex <= #self.m_children")
    local outStatus, outActiveChildIndex = self.m_node:selectorUpdate(agent, tick, childStatus, self.m_activeChildIndex, self.m_children)
    self.m_activeChildIndex = outActiveChildIndex
    return outStatus
end

return _M