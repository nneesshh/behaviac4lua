--- Behaviac lib Component: referenced behavior task.
-- @module ReferencedBehaviorTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local SingleChildNode = require(ppdir .. "core.SingleChildNode")
local ReferencedBehaviorTask = class("ReferencedBehaviorTask", SingleChildNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("ReferencedBehaviorTask", ReferencedBehaviorTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("ReferencedBehaviorTask", "SingleChildNode")
local _M = ReferencedBehaviorTask

local BehaviorTreeFactory = require(ppdir .. "parser.BehaviorTreeFactory")
local State = require(ppdir .. "fsm.State")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_nextStateId  = -1
    self.m_subTree      = false
end

function _M:release()
    _M.super.release(self)

    self.m_subTree      = false
end

function _M:onEvent(agent, eventName, eventParams)
    if self.m_status == EBTStatus.BT_RUNNING and self.m_node:hasEvents() then
        _G.BEHAVIAC_ASSERT(self.m_subTree, "[_M:onEvent()] self.m_subTree")

        if not self.m_subTree:onEvent(agent, eventName, eventParams) then
            return false
        end
    end

    return true
end

function _M:onEnter(agent)
    _G.BEHAVIAC_ASSERT(self.m_node and self.m_node:isReferencedBehavior(), "[_M:onEnter()] self.m_node:isReferencedBehavior")
    self.m_nextStateId = -1
    local szTreePath = self.m_node:getReferencedTree(agent)
    
    -- to create the task on demand
    if szTreePath and (not self.m_subTree or StringUtils.compare(szTreePath, self.m_subTree:getBehaviorTreePath(), true)) then
        self.m_subTree = BehaviorTreeFactory.buildBehaviorTreeTask(szTreePath)
        self.m_node:setTaskParams(agent, self.m_subTree)
    elseif self.m_subTree then
        self.m_subTree:reset(agent)
    end
    return true
end

function _M:onExit(agent, status)
end

function _M:getNextStateId()
    return self.m_nextStateId
end

function _M:update(agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(self:getNode() and self:getNode():isReferencedBehavior(), "[_M:update()] self:getNode():isReferencedBehavior")
    local status = self.m_subTree:exec(agent)
    local bTransitioned, nextStateId = State.s_updateTransitions(agent, self.m_node, self.m_node.m_transitions, self.m_nextStateId, status)
    self.m_nextStateId = nextStateId

    if bTransitioned then
        if status == EBTStatus.BT_RUNNING then
            -- subtree not exited, but it will transition to other states
            self.m_subTree:abort(agent)
        end

        status = EBTStatus.BT_SUCCESS
    end

    return status
end

return _M