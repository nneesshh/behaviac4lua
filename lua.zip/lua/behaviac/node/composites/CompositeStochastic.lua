--- Behaviac lib Component: stochastic composite node.
-- @module CompositeStochastic.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local CompositeNode = require(ppdir .. "core.CompositeNode")
local CompositeStochastic = class("CompositeStochastic", CompositeNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("CompositeStochastic", CompositeStochastic)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("CompositeStochastic", "CompositeNode")
local _M = CompositeStochastic

local CompositeStochasticTask = require(cwd .. "CompositeStochasticTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_method   = false
end

function _M:release()
    _M.super.release(self)

    self.m_method   = false
end

function _M:onLoading(version, agentType, properties)
    _M.super.onLoading(self, version, agentType, properties)

    for _, p in ipairs(properties) do
        local randomGeneratorStr = p["RandomGenerator"]

        if nil ~= randomGeneratorStr then
            self.m_method = NodeParser.parseMethod(randomGeneratorStr)
        end
    end
end

function _M:isCompositeStochastic()
    return true
end

function _M:isValid(agent, task)
    if not task:getNode() or not task:getNode():isCompositeStochastic() then
        return false
    end
    return _M.super.isValid(self, agent, task)
end

function _M:createTask()
    return CompositeStochasticTask.new()
end

return _M