--- Behaviac lib Component: sequence stochastic composite node.
-- @module SequenceStochastic.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
-- SequenceStochastic tick each of their children in a random order. If a child returns Failure,
-- so does the Sequence. If it returns Success, the Sequence will move on to the next child in line
-- and return Running.If a child returns Running, so does the Sequence and that same child will be
-- ticked again next time the Sequence is ticked.Once the Sequence reaches the end of its child list,
-- it returns Success and resets its child index – meaning the first child in the line will be ticked
-- on the next tick of the Sequence.
local CompositeStochastic = require(cwd .. "CompositeStochastic")
local SequenceStochastic = class("SequenceStochastic", CompositeStochastic)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("SequenceStochastic", SequenceStochastic)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("SequenceStochastic", "CompositeStochastic")
local _M = SequenceStochastic

local SequenceStochasticTask = require(cwd .. "SequenceStochasticTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:checkIfInterrupted(agent)
    return self:evaluteCustomCondition(agent)
end

function _M:isSequenceStochastic()
    return true
end

function _M:isValid(agent, task)
    if not task:getNode() or not task:getNode():isSequenceStochastic() then
        return false
    end

    return _M.super.isValid(self, agent, task)
end

function _M:createTask()
    return SequenceStochasticTask.new()
end

return _M