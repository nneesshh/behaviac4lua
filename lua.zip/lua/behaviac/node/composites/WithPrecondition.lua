--- Behaviac lib Component: with precondition composite node.
-- @module WithPrecondition.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local BaseNode = require(ppdir .. "core.BaseNode")
local WithPrecondition = class("WithPrecondition", BaseNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("WithPrecondition", WithPrecondition)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("WithPrecondition", "BaseNode")
local _M = WithPrecondition

local WithPreconditionTask = require(cwd .. "WithPreconditionTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:isWithPrecondition()
    return true
end

function _M:isValid(agent, task)
    if not task:getNode() or not task:getNode():isWithPrecondition() then
        return false
    end

    return _M.super.isValid(self, agent, task)
end

function _M:createTask()
    return WithPreconditionTask.new()
end

return _M