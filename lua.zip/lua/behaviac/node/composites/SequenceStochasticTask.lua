--- Behaviac lib Component: sequence stochastic task.
-- @module SequenceStochasticTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local CompositeNode = require(ppdir .. "core.CompositeNode")
local SequenceStochasticTask = class("SequenceStochasticTask", CompositeNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("SequenceStochasticTask", SequenceStochasticTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("SequenceStochasticTask", "CompositeNode")
local _M = SequenceStochasticTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:update(agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(self.m_activeChildIndex <= #self.m_children, "[_M:update()] self.m_activeChildIndex <= #self.m_children")
    
    local bFirst = true
    local node = self.m_node
    --  Keep going until a child behavior says its running.
    local s = childStatus

    while true do
        if not bFirst or s == EBTStatus.BT_RUNNING then
            local childIndex = self.m_set[self.m_activeChildIndex]
            local pBehavior = self.m_children[childIndex]

            if node:checkIfInterrupted(agent) then
                return EBTStatus.BT_FAILURE
            end

            s = pBehavior:exec(agent)
        end

        bFirst = false
        --  If the child fails, or keeps running, do the same.
        if s ~= EBTStatus.BT_SUCCESS then
            return s
        end

        --  Hit the end of the array, job done!
        self.m_activeChildIndex = self.m_activeChildIndex + 1
        if self.m_activeChildIndex > #self.m_children then
            return EBTStatus.BT_SUCCESS
        end
    end
end

return _M