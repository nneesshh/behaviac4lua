--- Behaviac lib Component: selector probability task.
-- @module SelectorProbabilityTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local CompositeNode = require(ppdir .. "core.CompositeNode")
local SelectorProbabilityTask = class("SelectorProbabilityTask", CompositeNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("SelectorProbabilityTask", SelectorProbabilityTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("SelectorProbabilityTask", "CompositeNode")
local _M = SelectorProbabilityTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_totalSum     = 0
    self.m_weightingMap = {}
end

function _M:release()
    _M.super.release(self)
end

function _M:onEnter(agent)
    _G.BEHAVIAC_ASSERT(#self.m_children > 0, "[_M:onEnter()] #self.m_children > 0")
    self.m_activeChildIndex = constInvalidChildIndex

    self.m_weightingMap = {}
    self.m_totalSum     = 0

    for _, task in ipairs(self.m_children) do
        _G.BEHAVIAC_ASSERT(task:isDecoratorWeightTask(), "[_M:onEnter()] task:isDecoratorWeightTask")
        local weight = task:getNode():getWeight(agent)
        table.insert(self.m_weightingMap, weight)
        self.m_totalSum = self.m_totalSum + weight
    end

    _G.BEHAVIAC_ASSERT(#self.m_weightingMap == #self.m_children, "[_M:onEnter()] #self.m_weightingMap == self.m_children")
    return true
end

function _M:onExit(agent, status)
    self.m_activeChildIndex = constInvalidChildIndex
end

function _M:update(agent, tick, childStatus)    
    _G.BEHAVIAC_ASSERT(self:getNode() and self:getNode():isSelectorProbability(), "[_M:update()] self:getNode():isSelectorProbability")
    if childStatus ~= EBTStatus.BT_RUNNING then
        return childStatus
    end

    local pSelectorProbabilityNode = self:getNode()
    -- check if we've already chosen a node to run
    if self.m_activeChildIndex ~= constInvalidChildIndex then
        local pNode = self.m_children[self.m_activeChildIndex]
        return pNode:exec(agent)
    end

    _G.BEHAVIAC_ASSERT(#self.m_weightingMap == #self.m_children, "[_M:update()] #self.m_weightingMap == #self.m_children")
    -- generate a number between 0 and the sum of the weights
    local chosen = self.m_totalSum * common.getRandomValue(pSelectorProbabilityNode.m_randomGenerator, agent)
    local sum = 0

    for i = 1, #self.m_children do
        local w = self.m_weightingMap[i]
        sum = sum + w

        if w > 0 and sum >= chosen then
            local pChild = self.m_children[i]
            local status = pChild:exec(agent)
            if status == EBTStatus.BT_RUNNING then
                self.m_activeChildIndex = i
            else
                self.m_activeChildIndex = constInvalidChildIndex
            end
            -- print("[_M:update()] 1", self.m_activeChildIndex, pChild.__name)
            return status
        end
    end
    -- print("[_M:update()]", self.m_activeChildIndex)
    return EBTStatus.BT_FAILURE
end

return _M