--- Behaviac lib Component: if else composite node.
-- @module IfElse.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
-- This node has three children: 'condition' branch, 'if' branch, 'else' branch. first, it executes
-- conditon, until it returns success or failure. if it returns success, it then executes 'if' branch,
-- else if it returns failure, it then executes 'else' branch.
local CompositeNode = require(ppdir .. "core.CompositeNode")
local Cls_IfElse = class("IfElse", CompositeNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("IfElse", Cls_IfElse)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("IfElse", "CompositeNode")
local _M = Cls_IfElse

local IfElseTask = require(cwd .. "IfElseTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctro(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:isIfElse()
    return true
end

function _M:isValid(agent, task)
    if not task:getNode() or not task:getNode():isIfElse() then
        return false
    end

    return _M.super.isValid(self, agent, task)
end

function _M:createTask()
    return IfElseTask.new()
end

return _M