--- Behaviac lib Component: if else task.
-- @module IfElseTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local CompositeNode = require(ppdir .. "core.CompositeNode")
local IfElseTask = class("IfElseTask", CompositeNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("IfElseTask", IfElseTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("IfElseTask", "CompositeNode")
local _M = IfElseTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:onEnter(agent)
    self.m_activeChildIndex = constInvalidChildIndex
    if #self.m_children == 3 then
        return true
    end

    _G.BEHAVIAC_ASSERT(false, "IfElseTask has to have three children: condition, if, else")
    return false
end

function _M:onExit(agent, status)
end

function _M:update(agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(childStatus ~= EBTStatus.BT_INVALID, "[_M:update()] childStatus ~= EBTStatus.BT_INVALID")
    _G.BEHAVIAC_ASSERT(#self.m_children == 3, "[_M:update()] #self.m_children == 3")

    local conditionResult = EBTStatus.BT_INVALID

    if childStatus == EBTStatus.BT_SUCCESS or childStatus == EBTStatus.BT_FAILURE then
        -- if the condition returned running then ended with childStatus
        conditionResult = childStatus
    end

    if self.m_activeChildIndex == constInvalidChildIndex then
        local pCondition = self.m_children[1]
        if conditionResult == EBTStatus.BT_INVALID then
            -- condition has not been checked
            conditionResult = tick:exec(pCondition, agent)
        end

        if conditionResult == EBTStatus.BT_SUCCESS then
            -- if
            self.m_activeChildIndex = 2
        elseif conditionResult == EBTStatus.BT_FAILURE then
            -- else
            self.m_activeChildIndex = 3
        end
    else
        return childStatus
    end

    if self.m_activeChildIndex ~= constInvalidChildIndex then
        local pBehavior = self.m_children[self.m_activeChildIndex]
        local s = pBehavior:exec(agent)
        return s
    end

    return EBTStatus.BT_RUNNING
end

return _M