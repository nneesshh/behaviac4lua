--- Behaviac lib Component: selector probability composite node.
-- @module SelectorProbability.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
-- Choose a child to execute based on the probability have set. then return the child execute result.
-- For example, if there were two children with a weight of one, each would have a 50% chance of being executed.
-- If another child with a weight of eight were added, the previous children would have a 10% chance of being
-- executed, and the new child would have an 80% chance of being executed.
-- This weight system is intended to facilitate the fine-tuning of behaviors.
local CompositeNode = require(ppdir .. "core.CompositeNode")
local SelectorProbability = class("SelectorProbability", CompositeNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("SelectorProbability", SelectorProbability)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("SelectorProbability", "CompositeNode")
local _M = SelectorProbability

local SelectorProbabilityTask = require(cwd .. "SelectorProbabilityTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_randomGenerator = false
end

function _M:release()
    _M.super.release()
    
    self.m_randomGenerator = false
end

function _M:onLoading(version, agentType, properties)
    _M.super.onLoading(self, version, agentType, properties)

    for _, p in ipairs(properties) do
        local randomGeneratorStr = p["RandomGenerator"]

        if nil ~= randomGeneratorStr then
            if randomGeneratorStr[0] ~= "" then
                self.m_randomGenerator = NodeParser.parseMethod(randomGeneratorStr)
            end
        else
            -- _G.BEHAVIAC_ASSERT(0, "unrecognized property")
        end
    end
end

function _M:addChild(pBehavior)
    _G.BEHAVIAC_ASSERT(pBehavior:isDecoratorWeight(), "[_M:addChild()] pBehavior:isDecoratorWeight")

    _M.super.addChild(self, pBehavior)
end

function _M:isSelectorProbability()
    return true
end

function _M:isValid(agent, task)
    if not task:getNode() or not task:getNode():isSelectorProbability() then
        return false
    end

    return _M.super.isValid(self, agent, task)
end

function _M:createTask()
    return SelectorProbabilityTask.new()
end

return _M