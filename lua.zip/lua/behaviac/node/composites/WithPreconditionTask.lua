--- Behaviac lib Component: with precondition task.
-- @module WithPreconditionTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local SequenceTask = require(cwd .. "SequenceTask")
local WithPreconditionTask = class("WithPreconditionTask", SequenceTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("WithPreconditionTask", WithPreconditionTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("WithPreconditionTask", "SequenceTask")
local _M = WithPreconditionTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:preconditionNode()
    _G.BEHAVIAC_ASSERT(#self.m_children == 2, "[_M:preconditionNode()] #self.m_children == 2")
    return self.m_children[1]
end

function _M:actionNode()
    _G.BEHAVIAC_ASSERT(#self.m_children == 2, "[_M:actionNode()] #self.m_children == 2")
    return self.m_children[2]
end

function _M:onEnter(agent)
    local pParent = self:getParent()
    -- when as child of SelctorLoop, it is not ticked normally
    _G.BEHAVIAC_ASSERT(pParent and pParent:isWithPreconditionLoopTask(), "[_M:onEnter()] pParent:isWithPreconditionLoopTask")
    return true
end

function _M:onExit(agent, status)
    local pParent = self:getParent()
    -- when as child of SelctorLoop, it is not ticked normally
    _G.BEHAVIAC_ASSERT(pParent and pParent:isWithPreconditionLoopTask(), "[_M:onExit()] pParent:isWithPreconditionLoopTask")
end

function _M:updateCurrent(agent, tick, childStatus)
    return self:update(agent, tick, childStatus)
end

function _M:update(agent, tick, childStatus)
    -- REDO: 因为_G.BEHAVIAC_ASSERT(false) 这个不应该被调用
    local pParent = self.getParent()
    _G.BEHAVIAC_ASSERT(pParent and pParent:isWithPreconditionLoopTask(), "[_M:update()] pParent:isWithPreconditionLoopTask")
    _G.BEHAVIAC_ASSERT(#self.m_children == 2, "[_M:update()] #self.m_children == 2")
    _G.BEHAVIAC_ASSERT(false)
    return EBTStatus.BT_RUNNING
end

return _M