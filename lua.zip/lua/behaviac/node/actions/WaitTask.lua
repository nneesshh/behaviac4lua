--- Behaviac lib Component: wait task.
-- @module WaitTaskTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local LeafTask = require(ppdir .. "core.LeafTask")
local WaitTaskTask = class("WaitTaskTask", LeafTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("WaitTaskTask", WaitTaskTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("WaitTaskTask", "LeafTask")
local _M = WaitTaskTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_start    = 0
    self.m_time     = 0
    self.m_intStart = 0
    self.m_intTime  = 0
end

function _M:release()
    _M.super.release(self)
end

function _M:copyTo(target)
    _M.super.copyTo(target)

    _G.BEHAVIAC_ASSERT(target:isWaitTask(), "[_M:copyTo()] target:isWaitTask")
    target.m_start      = self.m_start
    target.m_time       = self.m_time
end

function _M:onEnter(agent)
    self.m_start = common.getClock()
    self.m_time  = self:getNode():getTime(agent) or 0
    return self.m_time > 0 
end

function _M:onExit(agent, status)
end

function _M:update(agent, tick, childStatus)
    if common.getClock() - self.m_start >= self.m_time then
        return EBTStatus.BT_SUCCESS
    end
    return EBTStatus.BT_RUNNING
end

function _M:isWaitTask()
    return true
end

return _M