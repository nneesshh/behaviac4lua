--- Behaviac lib Component: compute task.
-- @module ComputeTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local LeafTask = require(ppdir .. "core.LeafTask")
local ComputeTask = class("ComputeTask", LeafTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("ComputeTask", ComputeTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("ComputeTask", "LeafTask")
local _M = ComputeTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:onEnter(agent)
    return true
end

function _M:onExit(agent, status)
end

function _M:update(agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(childStatus == EBTStatus.BT_RUNNING, "[_M:update()] childStatus == EBTStatus.BT_RUNNING")
    _G.BEHAVIAC_ASSERT(self:getNode() and self:getNode():isCompute(), "[_M:update()] self:getNode():isCompute()")
    local status = EBTStatus.BT_SUCCESS
    local pComputeNode = self:getNode()

    if pComputeNode.m_opl then
        pComputeNode.m_opl:compute(agent, pComputeNode.m_opr1, pComputeNode.m_opr2, pComputeNode.m_operator)
    else
        status = pComputeNode:updateImpl(agent, tick, childStatus)
    end
    return status
end

return _M