--- Behaviac lib Component: Wait for signal action node.
-- @module WaitForSignal.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
-- Always return Running until the predicates of WaitForSignalforSignal node become true,
-- or executing child node and return execution result.
local BaseNode = require(ppdir .. "core.BaseNode")
local WaitForSignal = class("WaitForSignal", BaseNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("WaitForSignal", WaitForSignal)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("WaitForSignal", "BaseNode")
local _M = WaitForSignal

local WaitForSignalTask = require(cwd .. "WaitForSignalTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:checkIfSignaled(agent)
    return self:evaluteCustomCondition(agent)
end

function _M:isWaitForSignal()
    return true
end

function _M:isValid(agent, task)
    if not task:getNode() or not task:getNode():isWaitForSignal() then
        return false
    end

    return _M.super.isValid(self, agent, task)
end

function _M:createTask()
    return WaitForSignalTask.new()
end

return _M