--- Behaviac lib Component: wait frames task.
-- @module WaitFramesTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local LeafTask = require(ppdir .. "core.LeafTask")
local WaitFramesTask = class("WaitFramesTask", LeafTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("WaitFramesTask", WaitFramesTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("WaitFramesTask", "LeafTask")
local _M = WaitFramesTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_start    = 0
    self.m_frames   = 0
end

function _M:release()
    _M.super.release(self)
end

function _M:copyTo(target)
    _M.super.copyTo(self, target)

    _G.BEHAVIAC_ASSERT(target:isWaitFramesTask(), "[_M:copyTo()] target:isWaitFramesTask()")
    target.m_start  = self.m_start
    target.m_frames = self.m_frames
end

function _M:onEnter(agent)
    self.m_start    = common.getFrames()
    self.m_frames   = self:getNode():getFrames(agent) or 0

    return self.m_frames > 0
end

function _M:onExit(agent)
end

function _M:update(agent, tick, childStatus)
    local frame = common.getFrames()

    if frame - self.m_start + 1 >= self.m_frames then
        return EBTStatus.BT_SUCCESS
    end
    return EBTStatus.BT_RUNNING
end

function _M:isWaitFramesTask()
    return true
end

return _M