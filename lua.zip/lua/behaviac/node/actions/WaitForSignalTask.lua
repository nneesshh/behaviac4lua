--- Behaviac lib Component: wait for signal task.
-- @module WaitForSignalTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local LeafTask = require(ppdir .. "core.LeafTask")
local WaitForSignalTask = class("WaitForSignalTask", LeafTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("WaitForSignalTask", WaitForSignalTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("WaitForSignalTask", "LeafTask")
local _M = WaitForSignalTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_bTriggered = false
end

function _M:release()
    _M.super.release(self)
end

function _M:copyTo(target)
    _M.super.copyTo(target)
    _G.BEHAVIAC_ASSERT(target:isWaitforSignalTask(), "[_M:copyTo()] target:isWaitforSignalTask")
    target.m_bTriggered = self.m_bTriggered
end

function _M:onEnter(agent)
    self.m_bTriggered = false
    return true
end

function _M:onExit(agent)
end

function _M:update(agent, tick, childStatus)
    if childStatus ~= EBTStatus.BT_RUNNING then
        return childStatus
    end

    if not self.m_bTriggered then
        self.m_bTriggered = self.m_node:checkIfSignaled(agent)
    end

    if self.m_bTriggered then
        if not self.m_root then
            return EBTStatus.BT_SUCCESS
        end
        return _M.super.update(agent, tick, childStatus)
    end

    return EBTStatus.BT_RUNNING
end

function _M:isWaitforSignalTask()
    return true
end

return _M