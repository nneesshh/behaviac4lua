--- Behaviac lib Component: end task.
-- @module EndTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local LeafTask = require(ppdir .. "core.LeafTask")
local EndTask = class("EndTask", LeafTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("EndTask", EndTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("EndTask", "LeafTask")
local _M = EndTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:getEndOutsides()
    local pEndNode = self:getNode()
    if pEndNode and pEndNode:isEnd() then
        return pEndNode:getEndOutside()
    end
    return false
end

function _M:getStatus(agent)
    local pEndNode = self:getNode()
    local status = EBTStatus.BT_SUCCESS
    if pEndNode and pEndNode:isEnd() then
        status = pEndNode:getStatus(agent)
    end
    _G.BEHAVIAC_ASSERT(status == EBTStatus.BT_SUCCESS or status == EBTStatus.BT_FAILURE, "[_M:getStatus()] status must be BT_SUCCESS BT_FAILURE")
    return status
end

function _M:onEnter(agent)
    return true
end

function _M:onExit(agent, status)
end

function _M:update(agent, tick, childStatus)
    local rootTask = nil    -- BehaviorTreeTask

    if self:getEndOutside() then
        rootTask = self:getRootTask()
    elseif agent then
        rootTask = agent:btgetcurrent()
    end

    if rootTask then
        local status = self:getStatus(agent)
        rootTask:setEndStatus(agent, status)
    end
end

return _M