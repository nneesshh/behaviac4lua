--- Behaviac lib Component: assignment task.
-- @module AssignmentTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local LeafTask = require(ppdir .. "core.LeafTask")
local AssignmentTask = class("AssignmentTask", LeafTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("AssignmentTask", AssignmentTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("AssignmentTask", "LeafTask")
local _M = AssignmentTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:onEnter(agent)
    return true
end

function _M:onExit(agent, status)
end

function _M:update(agent, tick, childStatus)
    _G.BEHAVIAC_ASSERT(childStatus == EBTStatus.BT_RUNNING, "[_M:update()] childStatus == EBTStatus.BT_RUNNING")
    _G.BEHAVIAC_ASSERT(self:getNode() and self:getNode():isAssignment(), "[_M:update()] self:getNode():isAssignment()")

    local pAssignmentNode = self:getNode()
    local status = EBTStatus.BT_SUCCESS

    if pAssignmentNode.m_opl then
        pAssignmentNode.m_opl:setValueCast(agent, pAssignmentNode.m_opr, pAssignmentNode.m_bCast)
    else
        status = pAssignmentNode:updateImpl(agent, tick, childStatus)
    end

    return status
end

return _M