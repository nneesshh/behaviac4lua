--- Behaviac lib Component: wait frames action node.
-- @module WaitFrames.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
-- Wait for the specified frames, and always return Running until exceeds count.
local BaseNode = require(ppdir .. "core.BaseNode")
local WaitFrames = class("WaitFrames", BaseNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("WaitFrames", WaitFrames)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("WaitFrames", "BaseNode")
local _M = WaitFrames

local WaitFramesTask = require(cwd .. "WaitFramesTask")
local NodeParser = require(ppdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_frames   = false
end

function _M:release()
    _M.super.release(self)

    self.m_frames = false
end

function _M:onLoading(version, agentType, properties)
    _M.super.onLoading(self)

    for _, p in ipairs(properties) do
        local framesStr = p["Frames"]

        if nil ~= framesStr then
            local pParenthesis = string.find(framesStr, "%(")
            if not pParenthesis then
                self.m_frames = NodeParser.parseProperty(framesStr)
            else
                self.m_frames = NodeParser.parseMethod(framesStr)
            end
        end
    end
end

function _M:getFrames(agent)
    if self.m_frames then
        local frames = self.m_frames:getValue(agent)
        if frames == 0xFFFFFFFF then
            return -1
        else
            return bits.bitAnd(frames, 0x0000FFFF)
        end
    end
    return 0
end

function _M:isWaitFrames()
    return true
end

function _M:createTask()
    return WaitFramesTask.new()
end

return _M