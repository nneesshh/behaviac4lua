--- Behaviac lib Component: and task.
-- @module AndTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local SequenceTask = require(pdir .. "composites.SequenceTask")
local AndTask = class("AndTask", SequenceTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("AndTask", AndTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("AndTask", "SequenceTask")
local _M = AndTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:update(agent, tick, childStatus)
    for _, child in ipairs(self.m_children) do
        local status = child:exec(agent)
        -- If the child fails, fails
        if status == EBTStatus.BT_FAILURE then
            return status
        end

        _G.BEHAVIAC_ASSERT(status == EBTStatus.BT_SUCCESS, "[_M:update()] status == EBTStatus.BT_SUCCESS")
    end

    return EBTStatus.BT_SUCCESS
end

return _M