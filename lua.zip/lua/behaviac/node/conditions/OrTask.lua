--- Behaviac lib Component: or task.
-- @module OrTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local ppdir = (...):gsub('%.[^%.]+%.[^%.]+%.[^%.]+$', '') .. "."
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(ppdir .. "enums")
local common = require(ppdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local SelectorTask = require(pdir .. "composites.SelectorTask")
local OrTask = class("OrTask", SelectorTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("OrTask", OrTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("OrTask", "SelectorTask")
local _M = OrTask

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)
end

function _M:release()
    _M.super.release(self)
end

function _M:update(agent, tick, childStatus)
    for _, child in ipairs(self.m_children) do
        local status = child:exec(agent)
        -- If the child succeeds, succeeds
        if status == EBTStatus.BT_SUCCESS then
            return status
        end

        _G.BEHAVIAC_ASSERT(status == EBTStatus.BT_FAILURE, "cOrTask:update status == EBTStatus.BT_FAILURE")
    end

    return EBTStatus.BT_FAILURE
end

return _M