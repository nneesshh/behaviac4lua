--- Behaviac lib Component: task task.
-- @module TaskTask.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(pdir .. "enums")
local common = require(pdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local SequenceTask = require(pdir .. "node.composites.SequenceTask")
local TaskTask = class("TaskTask", SequenceTask)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("TaskTask", TaskTask)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("TaskTask", "SequenceTask")
local _M = TaskTask

local BranchNode = require(pdir .. "core.BranchNode")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self._planner = false
end

function _M:release()
    _M.super.release(self)

    self._planner = false
end

function _M:init(node)
    _G.BEHAVIAC_ASSERT(node and node:isTask(), "node is not a task")

    if node:isHTN() then
        BranchNode.init(self, node)
    else
        _M.super.init(self, node)
    end
end

function _M:copyto(target)
    _M.super.copyto(self, target)
end

function _M:addChild(pBehavior)
    _M.super.addChild(self, pBehavior)
end

function _M:onEnter(agent)
    self.m_activeChildIndex = constInvalidChildIndex
    pTaskNode = self:getNode()

--[[#if BEHAVIAC_USE_HTN
        _planner->Init(agent, pTaskNode)
#endif //BEHAVIAC_USE_HTN]]
        --_G.BEHAVIAC_UNUSED_VAR(pTaskNode)

    return _M.super.onEnter(self, agent)
end

function _M:onExit(agent, s)
    _M.super.onExit(self, agent, s)
end

function _M:update(agent, tick, childStatus)
    local status = childStatus

    if childStatus == EBTStatus.BT_RUNNING then
        _G.BEHAVIAC_ASSERT(self:getNode() and self:getNode():isTask(), "node is not a task")
        pTaskNode = self:getNode()

        if pTaskNode:isHTN() then
--[[#if BEHAVIAC_USE_HTN
            status = _planner->Update()
#endif //BEHAVIAC_USE_HTN]]
        else
            _G.BEHAVIAC_ASSERT(#self.m_children == 1)
            c = self.m_children[1]
            status = c:exec(agent)
        end
    end

    return status
end

return _M