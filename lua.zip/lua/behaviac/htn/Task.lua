--- Behaviac lib Component: task htn node.
-- @module Task.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

-- Localize
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local enums = require(pdir .. "enums")
local common = require(pdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

-- Class
local BaseNode = require(pdir .. "core.BaseNode")
local Task = class("Task", BaseNode)
_G.ADD_BEHAVIAC_DYNAMIC_TYPE("Task", Task)
_G.BEHAVIAC_DECLARE_DYNAMIC_TYPE("Task", "BaseNode")
local _M = Task

local TaskTask = require(cwd .. "TaskTask")
local NodeParser = require(pdir .. "parser.NodeParser")

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

-- ctor
function _M:ctor()
    _M.super.ctor(self)

    self.m_bHTN = false
    self.m_task = false
end

function _M:release()
    _M.super.release(self)

    self.m_task = false
end

function _M:onLoading(version, agentType, properties)
    _M.super.onLoading(self, version, agentType, properties)

    for _, p in ipairs(properties) do
        local prototypeStr = p["Prototype"]
        local isHTNStr = p["IsHTN"]

        if nil ~= prototypeStr then
            self.m_task = NodeParser.parseMethod(prototypeStr)
        elseif nil ~= isHTNStr then
            self.m_bHTN = (isHTNStr == "true")
        else
            -- _G.BEHAVIAC_ASSERT(0, "unrecognized property")
        end
    end
end

function _M:FindMethodIndex(method)
    if self.m_children then
        for i, oneChild in ipairs(self.m_children) do
            if oneChild == method then
                return i
            end
        end
    end

    return constInvalidChildIndex
end

function _M:isHTN()
    return self.m_bHTN
end

function _M:isTask()
    return true
end

function _M:isValid(agent, task)
    if not task:getNode() or not task:getNode():isTask() then
        return false
    end

    return _M.super.isValid(agent, task)
end

function _M:createTask()
    return TaskTask.new()
end

return _M