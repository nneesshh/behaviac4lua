--- Behaviac lib Component: node parser.
-- @module NodeParser.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

local _M = {

    constCharByteDoubleQuote     = string.byte('\"'),
    constCharByteLeftBracket     = string.byte('['),
    constCharByteRightBracket    = string.byte(']'),
    constCharByteLeftBraces      = string.byte('{'),
    constCharByteComma           = string.byte(","),

}

-- Localize
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."
local unpack = unpack or table.unpack

local enums = require(pdir .. "enums")
local common = require(pdir .. "common")

local EBTStatus                 = enums.EBTStatus
local ENodePhase                = enums.ENodePhase
local EPreconditionPhase        = enums.EPreconditionPhase
local TriggerMode               = enums.TriggerMode
local EOperatorType             = enums.EOperatorType

local constSupportedVersion     = enums.constSupportedVersion
local constInvalidChildIndex    = enums.constInvalidChildIndex
local constBaseKeyStrDef        = enums.constBaseKeyStrDef
local constPropertyValueType    = enums.constPropertyValueType

local Logging                   = common.d_log
local StringUtils               = common.StringUtils

local AgentMeta = require(pdir .. "agent.AgentMeta")

--
local param_mt_ = {}
function param_mt_:run(agent)
    -- print("param_mt_:run", self.methodName, self.isFunction, self.valueIsFunction)
    if self.isFunction and self.valueIsFunction then
        self.value(agent, _M.unpackParams(agent, self.params))
    end
end

function param_mt_:setValueCast(agent, opr, cast)
    -- cast is unused
    local r = opr:getValue(agent)
    self.setValue(agent, r)
end

function param_mt_:getValue(agent)
    if not self.valueIsFunction then
        return self.value
    end
    if self.params then
        return self.value(agent, _M.unpackParams(agent, self.params))
    else
        return self.value(agent)
    end
end

function param_mt_:getValueFrom(agent, method)
    local fp = method:getValue(agent)
    if not self.valueIsFunction then
        return self.value
    end
    if self.params then
        return self.value(agent, fp, _M.unpackParams(agent, self.params))
    else
        return self.value(agent, fp)
    end
end

-- Compute(pAgent, pComputeNode->m_opr1, pComputeNode->m_opr2, pComputeNode->m_operator)
function param_mt_:compute(agent, opr1, opr2, operator)
    local r1 = opr1:getValue(agent)
    local r2 = opr2:getValue(agent)
    local result = _M.compute(r1, r2, operator)
    self.setValue(agent, result)
end

function param_mt_:compare(agent, opr, operatorType)
    local l = self:getValue(agent)
    local r = opr:getValue(agent)
    return _M.compare(l, r, operatorType)
end

function param_mt_:setTaskParams(agent, treeTask)
end

local function splitTokens(str)
    local ret = {}
    if string.byte(str, 1, 1) == _M.constCharByteDoubleQuote then
        _G.BEHAVIAC_ASSERT(string.byte(str, -1, -1) == _M.constCharByteDoubleQuote, "splitTokens string.byte(str, -1, -1) == constCharByteDoubleQuote")
        table.insert(ret, str)
        return ret
    end
    
    local p = StringUtils.split(str, ' ')
    local len = #p

    if string.byte(p[len], -1, -1) == _M.constCharByteRightBracket then
        local b = string.find(p[len], '%[')
        _G.BEHAVIAC_ASSERT(b, "splitTokens string.find(p[len], '%[')")
        p[len] = string.sub(v, 1, b-1)
        p[len+1] = string.sub(v, b+1, -1)
    end
    return p
end

function _M.unpackParams(agent, params)
    -- agent is unused
    return unpack(params)
end

function _M.parseMethod(methodInfo)
    if StringUtils.isNullOrEmpty(methodInfo) then
        return nil, false
    end

    -- self:funtionName(params)
    -- _G:fff.fff()
    -- local intanceName, methodName, paramStr = string.gmatch(methodInfo, "(.+):(.+)%((.+)%)")()
    -- REDO:  Self.CBTPlayer::MoveAhead(0)
    local intanceName, className, methodName, paramStr = string.gmatch(methodInfo, "(.+)%.(.+)::(.+)%((.*)%)")()
    _G.BEHAVIAC_ASSERT(intanceName and className and methodName, "_M.parseMethod " .. methodInfo)
    -- print('>>>>>>>>parseMethod', intanceName, methodName, paramStr)
    local data = {
        isFunction     = true,
        intanceName    = intanceName,
        methodName     = methodName,
        params         = _M.parseForParams(paramStr),
    }

    local function methodIsNotImplementedYetError()
        print(methodInfo .. " error: method is not implemented yet!!!")
    end

    local function metaNotFoundError()
        print(intanceName .. "." .. className .. " error: meta not found!!!")
    end

    if string.lower(intanceName) == "self" then
        data.value = function(agent, ...)
            agent[methodName] = agent[methodName] or methodIsNotImplementedYetError
            return agent[methodName](agent, ...)
        end
        data.valueIsFunction = true
    else
        data.value = function(agent, ...)
            local other = AgentMeta.getInstance(intanceName, className)
            local otherMethod = nil
            if nil ~= other then
                otherMethod = other[methodName] or methodIsNotImplementedYetError
            else
                otherMethod = metaNotFoundError
            end
            return otherMethod(agent, ...)
        end
        data.valueIsFunction = true
    end
    return setmetatable(data, {__index = param_mt_}), methodName
end

-- 
function _M.parseForParams(paramStr)
    local params = {}
    
    local startIndex = 1
    local endIndex = #paramStr
    local quoteDepth = 0

    for i = startIndex, endIndex do
        local b = string.byte(paramStr, i)
        if _M.constCharByteDoubleQuote == b then
            quoteDepth = (quoteDepth + 1) % 2
        elseif 0 == quoteDepth and _M.constCharByteComma == b then
            local s = string.trim(string.sub(paramStr, startIndex, i - 1))
            table.insert(params, s)
            startIndex = i + 1
        end
    end

    -- the last param
    if endIndex > startIndex then
        local s = string.trim(string.sub(paramStr, startIndex, endIndex))
        table.insert(params, s)
    end

    return params
end

function _M.parseProperty(propertyStr)
    if StringUtils.isNullOrEmpty(propertyStr) then
        return nil
    end
    local data = { isFunction = false }
    local tokens = splitTokens(propertyStr)

    -- const number/table/string 0/{x=1,y=1,z=1}/"111"
    if tokens[1] == "const" then
        BEHAVIAC_ASSERT(#tokens == 3, "_M.parseProperty #tokens == 3")
        data.type  = constPropertyValueType.const
        data.value = common.readBasicType(tokens[2], tokens[3]) 
        data.valueIsFunction = false
        return setmetatable(data, {__index = param_mt_})
    else
        local propStr       = ""
        local typeName      = ""
        local indexPropStr  = ""
        if tokens[1] == "static" then
            -- static number/table/str Self.m_s_float_type_0
            -- static number/table/str _G.xxx.yyy
            BEHAVIAC_ASSERT(#tokens == 3 or #tokens == 4, "_M.parseProperty static #tokens ~= 3, 4")
            typeName = tokens[2]
            propStr  = tokens[3]
            data.type  = constPropertyValueType.static

            -- array index
            if #tokens >= 4 then
                indexPropStr = tokens[4]
            end
        else
            -- number/table/str Self.m_s_float_type_0
            -- number/table/str _G.xxx.yyy
            BEHAVIAC_ASSERT(#tokens == 2 or #tokens == 3, "_M.parseProperty non-static #tokens ~= 2, 3")
            typeName = tokens[1]
            propStr  = tokens[2]
            data.type  = constPropertyValueType.default

            -- array index
            if #tokens >= 3 then
                indexPropStr = tokens[3]
            end
        end
        
        local indexMember = 0

        --//if (!StringUtils::IsNullOrEmpty(indexPropStr))
        if #indexPropStr > 0 then
            indexMember = tonumber(indexPropStr)
        end
        
        local intanceName, className, propertyName = string.gmatch(propStr, "(.+)%.(.+)::(.+)")()
        if string.lower(intanceName) == "self" then
            _G.BEHAVIAC_ASSERT(propertyName, "_M.parseProperty() property name can't be nil")
            data.value = function(agent)
                local val = agent[propertyName]
                if val then
                    return val
                else
                    return agent:getVarValue(propertyName)
                end
            end
            data.setValue = function(agent, value)
                agent[propertyName] = value
            end
            data.valueIsFunction = true
        else
            data.value = function(agent)
                local other = AgentMeta.getInstance(intanceName, className)
                return other and other[propertyName]
            end
            data.setValue = function(agent, value)
                local other = AgentMeta.getInstance(intanceName, className)
                if nil ~= other then
                    other[propertyName] = value
                end
            end
            data.valueIsFunction = true
        end

        return setmetatable(data, {__index = param_mt_})
    end
end

function _M.parseMethodOutMethodName(methodInfo)
    return _M.parseMethod(methodInfo)
end

local operator_type_parser_ = {
    ["Invalid"] = EOperatorType.E_INVALID,
    ["Assign"] = EOperatorType.E_ASSIGN,
    ["Add"] = EOperatorType.E_ADD,
    ["Sub"] = EOperatorType.E_SUB,
    ["Mul"] = EOperatorType.E_MUL,
    ["Div"] = EOperatorType.E_DIV,
    ["Equal"] = EOperatorType.E_EQUAL,
    ["NotEqual"] = EOperatorType.E_NOTEQUAL,
    ["Greater"] = EOperatorType.E_GREATER,
    ["Less"] = EOperatorType.E_LESS,
    ["GreaterEqual"] = EOperatorType.E_GREATEREQUAL,
    ["LessEqual"] = EOperatorType.E_LESSEQUAL,
}
function _M.parseOperatorType(operatorTypeStr)
    return operator_type_parser_[operatorTypeStr]
end

function _M.compare(left, right, operatorType)
    if nil == left or nil == right then
        print("_M.compare() failed, left or right operand is nil --", left, right)
        return false
    else
        if operatorType == EOperatorType.E_EQUAL then
            return left == right
        elseif operatorType == EOperatorType.E_NOTEQUAL then
            return left ~= right
        elseif operatorType == EOperatorType.E_GREATER then
            return left > right
        elseif operatorType == EOperatorType.E_GREATEREQUAL then
            return left >= right
        elseif operatorType == EOperatorType.E_LESS then
            return left < right
        elseif operatorType == EOperatorType.E_LESSEQUAL then
            return left <= right
        end
        print("_M.compare() failed, unknown operator type --", operatorType)
        return false
    end
end

function _M.compute(left, right, computeType)
    -- TODO left, right类型检查
    if type(left) ~= 'number' or type(right) ~= 'number' then
        _G.BEHAVIAC_ASSERT(false)
    else
        if computeType == EOperatorType.E_ADD then
            return left + right
        elseif computeType == EOperatorType.E_SUB then
            return left - right
        elseif computeType == EOperatorType.E_MUL then
            return left * right
        elseif computeType == EOperatorType.E_DIV then
            if right == 0 then
                print('error!!! _M.compute Divide right is zero.')
                return left
            end
            return left / right
        end
    end
    _G.BEHAVIAC_ASSERT(false)
    return left
end

return _M