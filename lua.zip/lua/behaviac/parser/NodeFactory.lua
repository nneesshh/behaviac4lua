--- Behaviac lib Component: node factory.
-- @module NodeFactory.lua
-- @author n.lee
-- @copyright 2016
-- @license MIT/X11

local _M = {}

-- Localize
local pdir = (...):gsub('%.[^%.]+%.[^%.]+$', '') .. "."
local cwd = (...):gsub('%.[^%.]+$', '') .. "."

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------
-- core
_M.BaseNode                     = require(pdir .. "core.BaseNode")
_M.BranchNode                   = require(pdir .. "core.BranchNode")
_M.SingleChildNode              = require(pdir .. "core.SingleChildNode")
_M.BehaviorTree                 = require(pdir .. "core.BehaviorTree")
_M.CompositeNode                = require(pdir .. "core.CompositeNode")
_M.Decorator                    = require(pdir .. "core.Decorator")
_M.DecoratorTask                = require(pdir .. "core.DecoratorTask")
_M.LeafTask                     = require(pdir .. "core.LeafTask")
_M.Action                       = require(pdir .. "core.Action")
_M.Condition                    = require(pdir .. "core.Condition")
_M.ConditionBaseTask            = require(pdir .. "core.ConditionTask")

-- attachments
_M.AttachAction                 = require(pdir .. "attachments.AttachAction")
_M.Effector                     = require(pdir .. "attachments.Effector")
_M.Event                        = require(pdir .. "attachments.Event")
_M.Precondition                 = require(pdir .. "attachments.Precondition")

-- node.actions
_M.Assignment                   = require(pdir .. "node.actions.Assignment")
_M.AssignmentTask               = require(pdir .. "node.actions.AssignmentTask")
_M.Compute                      = require(pdir .. "node.actions.Compute")
_M.ComputeTask                  = require(pdir .. "node.actions.ComputeTask")
_M.End                          = require(pdir .. "node.actions.End")
_M.EndTask                      = require(pdir .. "node.actions.EndTask")
_M.Noop                         = require(pdir .. "node.actions.Noop")
_M.NoopTask                     = require(pdir .. "node.actions.NoopTask")
_M.Wait                         = require(pdir .. "node.actions.Wait")
_M.WaitForSignal                = require(pdir .. "node.actions.WaitForSignal")
_M.WaitForSignalTask            = require(pdir .. "node.actions.WaitForSignalTask")
_M.WaitFrames                   = require(pdir .. "node.actions.WaitFrames")
_M.WaitFramesTask               = require(pdir .. "node.actions.WaitFramesTask")
_M.WaitTask                     = require(pdir .. "node.actions.WaitTask")

-- node.composites
_M.CompositeStochastic          = require(pdir .. "node.composites.CompositeStochastic")
_M.CompositeStochasticTask      = require(pdir .. "node.composites.CompositeStochasticTask")
_M.IfElse                       = require(pdir .. "node.composites.IfElse")
_M.IfElseTask                   = require(pdir .. "node.composites.IfElseTask")
_M.Parallel                     = require(pdir .. "node.composites.Parallel")
_M.ParallelTask                 = require(pdir .. "node.composites.ParallelTask")
_M.ReferencedBehavior           = require(pdir .. "node.composites.ReferencedBehavior")
_M.ReferencedBehaviorTask       = require(pdir .. "node.composites.ReferencedBehaviorTask")
_M.Selector                     = require(pdir .. "node.composites.Selector")
_M.SelectorLoop                 = require(pdir .. "node.composites.SelectorLoop")
_M.SelectorLoopTask             = require(pdir .. "node.composites.SelectorLoopTask")
_M.SelectorProbability          = require(pdir .. "node.composites.SelectorProbability")
_M.SelectorProbabilityTask      = require(pdir .. "node.composites.SelectorProbabilityTask")
_M.SelectorStochastic           = require(pdir .. "node.composites.SelectorStochastic")
_M.SelectorStochasticTask       = require(pdir .. "node.composites.SelectorStochasticTask")
_M.SelectorTask                 = require(pdir .. "node.composites.SelectorTask")
_M.Sequence                     = require(pdir .. "node.composites.Sequence")
_M.SequenceStochastic           = require(pdir .. "node.composites.SequenceStochastic")
_M.SequenceStochasticTask       = require(pdir .. "node.composites.SequenceStochasticTask")
_M.SequenceTask                 = require(pdir .. "node.composites.SequenceTask")
_M.WithPrecondition             = require(pdir .. "node.composites.WithPrecondition")
_M.WithPreconditionTask         = require(pdir .. "node.composites.WithPreconditionTask")

-- node.conditions
_M.And                          = require(pdir .. "node.conditions.And")
_M.AndTask                      = require(pdir .. "node.conditions.AndTask")
_M.False                        = require(pdir .. "node.conditions.False")
_M.FalseTask                    = require(pdir .. "node.conditions.FalseTask")
_M.Or                           = require(pdir .. "node.conditions.Or")
_M.OrTask                       = require(pdir .. "node.conditions.OrTask")
_M.True                         = require(pdir .. "node.conditions.True")
_M.TrueTask                     = require(pdir .. "node.conditions.TrueTask")

-- node.decorators
_M.DecoratorAlwaysFailure       = require(pdir .. "node.decorators.DecoratorAlwaysFailure")
_M.DecoratorAlwaysRunning       = require(pdir .. "node.decorators.DecoratorAlwaysRunning")
_M.DecoratorAlwaysRunningTask   = require(pdir .. "node.decorators.DecoratorAlwaysRunningTask")
_M.DecoratorAlwaysSuccess       = require(pdir .. "node.decorators.DecoratorAlwaysSuccess")
_M.DecoratorAlwaysSuccessTask   = require(pdir .. "node.decorators.DecoratorAlwaysSuccessTask")
_M.DecoratorCount               = require(pdir .. "node.decorators.DecoratorCount")
_M.DecoratorCountTask           = require(pdir .. "node.decorators.DecoratorCountTask")
_M.DecoratorCountLimit          = require(pdir .. "node.decorators.DecoratorCountLimit")
_M.DecoratorCountLimitTask      = require(pdir .. "node.decorators.DecoratorCountLimitTask")
_M.DecoratorCountOnce           = require(pdir .. "node.decorators.DecoratorCountOnce")
_M.DecoratorCountOnceTask       = require(pdir .. "node.decorators.DecoratorCountOnceTask")
_M.DecoratorFailureUntil        = require(pdir .. "node.decorators.DecoratorFailureUntil")
_M.DecoratorFailureUntilTask    = require(pdir .. "node.decorators.DecoratorFailureUntilTask")
_M.DecoratorFrames              = require(pdir .. "node.decorators.DecoratorFrames")
_M.DecoratorFramesTask          = require(pdir .. "node.decorators.DecoratorFramesTask")
_M.DecoratorIterator            = require(pdir .. "node.decorators.DecoratorIterator")
_M.DecoratorLog                 = require(pdir .. "node.decorators.DecoratorLog")
_M.DecoratorLogTask             = require(pdir .. "node.decorators.DecoratorLogTask")
_M.DecoratorLoop                = require(pdir .. "node.decorators.DecoratorLoop")
_M.DecoratorLoopTask            = require(pdir .. "node.decorators.DecoratorLoopTask")
_M.DecoratorLoopUntil           = require(pdir .. "node.decorators.DecoratorLoopUntil")
_M.DecoratorLoopUntilTask       = require(pdir .. "node.decorators.DecoratorLoopUntilTask")
_M.DecoratorNot                 = require(pdir .. "node.decorators.DecoratorNot")
_M.DecoratorNotTask             = require(pdir .. "node.decorators.DecoratorNotTask")
_M.DecoratorRepeat              = require(pdir .. "node.decorators.DecoratorRepeat")
_M.DecoratorRepeatTask          = require(pdir .. "node.decorators.DecoratorRepeatTask")
_M.DecoratorSuccessUntil        = require(pdir .. "node.decorators.DecoratorSuccessUntil")
_M.DecoratorSuccessUntilTask    = require(pdir .. "node.decorators.DecoratorSuccessUntilTask")
_M.DecoratorTime                = require(pdir .. "node.decorators.DecoratorTime")
_M.DecoratorTimeTask            = require(pdir .. "node.decorators.DecoratorTimeTask")
_M.DecoratorEveryTime           = require(pdir .. "node.decorators.DecoratorEveryTime")
_M.DecoratorEveryTimeTask       = require(pdir .. "node.decorators.DecoratorEveryTimeTask")
_M.DecoratorWeight              = require(pdir .. "node.decorators.DecoratorWeight")
_M.DecoratorWeightTask          = require(pdir .. "node.decorators.DecoratorWeightTask")

-- fsm
_M.State                        = require(pdir .. "fsm.State")
_M.StateTask                    = require(pdir .. "fsm.StateTask")

-- htn
_M.Task                         = require(pdir .. "htn.Task")
_M.TaskTask                     = require(pdir .. "htn.TaskTask")

return _M